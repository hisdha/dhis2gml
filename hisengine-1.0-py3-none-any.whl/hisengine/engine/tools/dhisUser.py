import hisengine.hisApi as ha
import sys,argparse
import json,bunch

def main(argv):
    parser = argparse.ArgumentParser(description="Manipulate DHIS2 Users")
    parser.add_argument("-l","--secrets",help="Specify file (json)")
    parser.add_argument("-s","--streaming",help="Stream online via Web API")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-d","--download",help="download data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    args = parser.parse_args()
    ggd = ha.hisApi()
    secrets = ggd.getAuth()
    session = ggd.getLoginSession(secrets['dtal']['username'],secrets['dtal']['password'],sid='DHIS2')
    #params = {"paging":"false","fields":"*"}
    params = {"paging":"false","fields":"*,!lastUpdated,!created,!access,!displayName,!favorite,!twoFA,!externalAuth,!externalAccess,userCredentials[*,!lastUpdated,!created,!lastLogin,!displayName,!favorite,!twoFA,!externalAuth,!externalAccess,!access]","filter":"id:in:[ZNCvTRTOq04,PpgveF538R3,xyMdiTi2cBQ,vWSj1CezbtX,fClwWaX6TQW,Lvq5Mlglqpd,sVkzupTxXdN,dANcUfVU9Lx,LAWmP82OYXT,pjQKyUuTX18,trDLs9pZiW4]"}
    #params = {"paging":"false","fields":"id,userCredentials[userRoles[id]]","filter":"id:eq:L5NueExSab2"}
    fileName = args.fileName
    if args.params is not None:
        params = args.params
    dUsers= ggd.getDHIS2Item(secrets['dtal']['url'],session,'users',params=params)
    users = dUsers['users']
    for user in users:
        update = False
        if "userCredentials" in user:
            if len(user['userCredentials']['userRoles']) == 1 and user['userCredentials']['userRoles'][0]['id'] == "b2uHwX9YLhu":
                pass
            elif len(user['userCredentials']['userRoles']) == 0:
                pass
            else:
                for userRole in user['userCredentials']['userRoles']:
                    if userRole['id'] != "jtzbVV4ZmdP" or userRole['id'] != "iBV77xiHMDz":
                        user['userCredentials']['userRoles']=[{"id":"b2uHwX9YLhu"}]
                        update = True
                    else:
                        pass
                if update:
                    print("Updating users")
                    userEndpoint = "{}/{}".format('users',user['id'])
                    ggd.updateDHIS2Item(secrets['dtal']['url'],session,userEndpoint,user)
        else:
            pass
    #print("Updating users",users)
    #ggd.postDHIS2Item(secrets['dtal']['url'],session,'users',{"users":users})

if __name__ == "__main__":
    main(sys.argv[1:])
