from hisengine import getGesisDhis2 as gesisd
import sys,argparse
import json,bunch

def main(argv):
    parser = argparse.ArgumentParser(description="Importing Gesis data - Access database")
    parser.add_argument("-l","--secrets",help="Specify file (json)")
    parser.add_argument("-s","--streaming",help="Stream online via Web API")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-pf","--filterParams",help="Specify filters parameters e.g id,code,name")
    parser.add_argument("-i","--indicators",help="process indicators")
    parser.add_argument("-d","--download",help="download data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    parser.add_argument("-dm","--destMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    parser.add_argument("-sm","--srcMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    args = parser.parse_args()
    startImport= gesisd.getGesisDHIS2()
    secrets = startImport.getAuth()
    session = startImport.getLoginSession(secrets['zmdhis']['username'],secrets['zmdhis']['password'],sid='DHIS2')
    mgsession = startImport.getLoginSession(secrets['dhis']['username'],secrets['dhis']['password'],sid='DHIS2')
    params = {"paging":"false","fields":"id,name,code"}
    filteredParams = {"paging":"false","fields":"id,name,level,code,ancestors[id,name,code,level,]","filter":"name:ilike:delete"}
    fileName = args.fileName
    if args.params is not None:
        params = args.params
    if args.filterParams is not None:
        filteredParams = args.filterParams
    if args.coding == 'test':
        print("Passed test")
    if args.coding == "lrs":
        dataSets =  startImport.getDHIS2Item(secrets['dhis']['url'],mgsession,'dataSets',params={"fields":"id","paging":"false"})
        dataSets = startImport.createArray(dataSets['dataSets'],'id')
        dataSetsString = ','.join(dataSets)
        checkDataParams= {"limit":1,"startDate":"1970-01-01","endDate":"2019-12-30","dataSet":dataSetsString}
        mgOrgUnits= startImport.getDHIS2OrgUnits(secrets['dhis']['url'],mgsession,params=filteredParams)
        trsMgOrgUnits = startImport.transformJson(mgOrgUnits)

        mgJsonOrgUnits = startImport.getPdFile(type='json',values=trsMgOrgUnits)
        mgJsonOrgUnits['Data Exist']=mgJsonOrgUnits.apply(startImport.checkOrgUnitData,args=('id',secrets['dhis']['url'],mgsession,checkDataParams),axis=1)
        startImport.createResultFile(mgJsonOrgUnits,'gesis','mg_mapping_duplicate_orgunits','csv')
        #lrsMapping= startImport.createMapping(sourceMap=zmJsonOrgUnits,destinationMap=dfSystem2,mappings=[{'old':code,'new':'dhis2Code'},{'old':'id','new':'dhis2Id'},{'old':'name','new':'dhis2Name'}],leftColumns=['cCodeStru'],rightColumns=['code'],category='ORGUNIT',resourceType='frs',authority='DHIS2')
    if args.coding == "trs":
        if args.streaming is None:
            if args.fileName is None:
                raise sys.exit('Please provide terminology/coding file')
            zmdataElements = startImport.getPdFile(fileName=fileName,type='csv',folder='zmdhis')
            trsMapping = startImport.createMapping(sourceMap=zmdataElements,category='DATALEMENT',resourceType='trs',authority='dhis2',map=False,categoryType='optionCombo')
            startImport.createResultFile(trsMapping,'zmdhis','zm_mapping_dataelements','csv')
            startImport.createResultFile(trsMapping,'zmdhis','zm_mapping_dataelements','json')
            startImport.updateDHIS2Item(secrets['zmdhis']['url'],session,'dataStore/terminology/indicators',json.loads(trsMapping.to_json(orient='records')))
        else:
            params = {"paging":"false","fields":"id,name,shortName,categoryOptionCombo[id,name],dataElement[id,name,code]"}
            catOptionParams = {"paging":"false","fields":"id,name"}
            indicatorParams = {"paging":"false","fields":"id,name,code,numerator,denominator,indicatorType[id,name],indicatorGroups[id,name]","filter":"indicatorGroups.name:in:[PEPFAR_DATIM_QUARTERLY,PEPFAR_DATIM_ANNUAL,PEPFAR_DATIM_SEMI_ANNUAL]"}
            filterColumns={'refIndicatorName','refIndicatorNumerator','refIndicatorDenominator','refIndicatorCategory','shortname','datimCode','datimId','datimCategoryOptionCombo','datimCategoryOptionComboId','safe_indicator','safeDisaggregation','disaggregation','indicator_id','indicatorSchema','formula','formulaSchema','frequency','active','category','categoryType','resourceType','system','disaggregationNewName','categoryOptionComboMatch'}
            trsIndicators= startImport.getDHIS2Item(secrets['zmdhis']['url'],session,'indicators',params=indicatorParams)
            trsIndicatorsTransformed = startImport.transformJson(trsIndicators['indicators'])
            trsIndDestMap = startImport.getPdFile(type='json',values=trsIndicatorsTransformed)
            # Save all indicators
            startImport.createResultFile(trsIndDestMap,'zmdhis','zm_mapping_trs_indicators','csv')
            trsUnMapped= startImport.getDHIS2Item(secrets['zmdhis']['url'],session,'dataElementOperands',params=params)
            trsTranformed= startImport.transformJson(trsUnMapped['dataElementOperands'])
            trsCatUnMapped= startImport.getDHIS2Item(secrets['zmdhis']['url'],session,'categoryOptionCombos',params=catOptionParams)
            #trsCatTranformed= startImport.transformJson(trsCatUnMapped['categoryOptionCombos'])
            trsCatDestMap = startImport.getPdFile(type='json',values=trsCatUnMapped['categoryOptionCombos'])
            trsCatDestMap[['disaggregationName']] = trsCatDestMap['name'].apply(startImport.cleanText)
            trsDestMap = startImport.getPdFile(type='json',values=trsTranformed)
            #trsDestMap = startImport.getPdFile(fileName='zm_mapping_trs_operands',type='csv',folder='zmdhis')
            startImport.createResultFile(trsDestMap,'zmdhis','zm_mapping_trs_operands','csv')
            zmdataElements = startImport.getPdFile(fileName=fileName,type='csv',folder='zmdhis')
            trsPreMapped = startImport.appendMatchedColumns(srcMap=zmdataElements,destMap=trsDestMap,left="datimCategoryOptionCombo",right="categoryOptionCombo_name",columnName=["safeDisaggregation","safename","categoryOptionComboMatch","disaggregation","matches"],match='search',fields=['categoryOptionCombo_id','categoryOptionCombo_name'])
            trsPreMapped.drop(columns=['matches','dataset','dataelement','datimDescription'],inplace=True)
            trsPreMapped = startImport.appendMatchedColumns(srcMap=trsPreMapped,destMap=trsDestMap,left="datimCategoryOptionCombo",right="categoryOptionCombo_name",columnName=["indicator_replaced","indicatorSchema"],match='replace')

            trsPreMapping = startImport.combineDataValues(trsPreMapped,data=trsCatDestMap,leftColumns=['categoryOptionComboMatch'],rightColumns=['disaggregationName'])
            trsPreMappedOptionCombo = startImport.appendMatchedColumns(srcMap=trsPreMapping,destMap=trsDestMap,dataElement='dataElement_id',optionCombo='indicator_replaced',check='id',columnName=["formula","formulaSchema"])
            trsMap = startImport.appendMatchedColumns(srcMap=trsPreMappedOptionCombo,destMap=trsIndDestMap,check='indicator_replaced',dataElement='numerator',match='compare',columnName=["indicator_id","refIndicatorName","refIndicatorDenominator","refIndicatorCategory","refIndicatorNumerator","indicatorMatch",'categoryType'],fields=['id','name','denominator','indicatorGroups_name'])
            trsMapping = startImport.createMapping(sourceMap=trsMap,category='dataelement',resourceType='trs',authority='datim',map=False,platform='dhis2')
            trsMappingFilter = trsMapping.filter(filterColumns)
            startImport.createResultFile(trsMappingFilter,'zmdhis','zm_mapping_trs','csv')
            #startImport.createResultFile(trsMappingFilter,'zmdhis','zm_mapping_trs','json')
            print("Updating datastore")
            startImport.updateDHIS2Item(secrets['zmdhis']['url'],session,'dataStore/terminology/indicator',json.loads(trsMappingFilter.to_json(orient='records')))
    else:
        pass

if __name__ == "__main__":
    main(sys.argv[1:])
