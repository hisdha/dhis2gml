import hisengine.engine.core.hisApi as hisApi
import hisengine.engine.core.mappingUtils as mappingUtils
import hisengine.engine.core.hisUtils as hisUtils
import sys,argparse
import json

def main(argv):
    parser = argparse.ArgumentParser(description="Create DHIS2 Mappings for Metadata")
    parser.add_argument("-l","--secrets",help="Specify file (json)")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-d","--path",help="path to secrets file")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-s","--streaming",help="Stream online via Web API")

    args = parser.parse_args()
    api = hisApi.hisApi()
    mu = mappingUtils.mappingUtils()
    hu = hisUtils.hisUtils()

    secrets = api.getAuth(path=args.path,secrets=args.secrets)
    session = api.getLoginSession(secrets['zmdhis']['username'],secrets['zmdhis']['password'],sid='DHIS2')
    # Set defaults parameters
    params = {"paging":"false","fields":"id,name,code"}
    fileName = args.fileName
    if args.params is not None:
        params = args.params
    if args.coding == "trs":
        if args.streaming is None:
            if args.fileName is None:
                raise sys.exit('Please provide terminology/coding/mapping file')
            zmdataElements = hu.getPdFile(fileName=fileName,type='csv',folder='zmdhis')
            trsMapping = mu.createMapping(sourceMap=zmdataElements,category='DATALEMENT',resourceType='trs',authority='dhis2',map=False,categoryType='optionCombo')
            hu.createResultFile(trsMapping,'zmdhis','zm_echo_mapping_dataelements','csv')
            hu.createResultFile(trsMapping,'zmdhis','zm_echo_mapping_dataelements','json')
            api.updateDHIS2Item(secrets['zmdhis']['url'],session,'dataStore/terminology/mappings',json.loads(trsMapping.to_json(orient='records')))
        else:
            params = {"paging":"false","fields":"id,name,shortName,categoryOptionCombo[id,name],dataElement[id,name,code]"}
            catOptionParams = {"paging":"false","fields":"id,name"}
            indicatorParams = {"paging":"false","fields":"id,name,code,numerator,denominator,indicatorType[id,name],indicatorGroups[id,name]","filter":"indicatorGroups.name:in:[ZM SAFE HTS_TST]"}
            filterColumns={'refIndicatorName','refIndicatorNumerator','refIndicatorDenominator','refIndicatorCategory','shortname','datimCode','datimId','datimCategoryOptionCombo','datimCategoryOptionComboId','safe_indicator','safeDisaggregation','disaggregation','indicator_id','indicatorSchema','formula','formulaSchema','frequency','active','category','categoryType','resourceType','system','disaggregationNewName','categoryOptionComboMatch'}
            trsIndicators= api.getDHIS2Item(secrets['zmdhis']['url'],session,'indicators',params=indicatorParams)
            
            trsIndDestMap = hu.flattenJsonData(trsIndicators['indicators'])

            # Save all indicators
            hu.createResultFile(trsIndDestMap,'zmdhis','zm_echo_mapping_trs_indicators','csv')
            trsUnMapped= api.getDHIS2Item(secrets['zmdhis']['url'],session,'dataElementOperands',params=params)
            trsTranformed= hu.flattenJsonData(trsUnMapped['dataElementOperands'])
            trsCatUnMapped= api.getDHIS2Item(secrets['zmdhis']['url'],session,'categoryOptionCombos',params=catOptionParams)
            #trsCatTranformed= hu.transformJson(trsCatUnMapped['categoryOptionCombos'])
            trsCatDestMap = hu.getPdFile(type='json',values=trsCatUnMapped['categoryOptionCombos'])
            trsCatDestMap[['disaggregationName']] = trsCatDestMap['name'].apply(mu.cleanText)
            trsDestMap = hu.getPdFile(type='json',values=trsTranformed)
            #trsDestMap = hu.getPdFile(fileName='zm_echo_mapping_trs_operands',type='csv',folder='zmdhis')
            hu.createResultFile(trsDestMap,'zmdhis','zm_echo_mapping_trs_operands','csv')
            zmdataElements = hu.getPdFile(fileName=fileName,type='csv',folder='zmdhis')
            trsPreMapped = mu.appendMatchedColumns(srcMap=zmdataElements,destMap=trsDestMap,left="datimCategoryOptionCombo",right="categoryOptionCombo_name",columnName=["safeDisaggregation","safename","categoryOptionComboMatch","disaggregation","matches"],match='search',fields=['categoryOptionCombo_id','categoryOptionCombo_name'])
            trsPreMapped.drop(columns=['matches','dataset','dataelement','datimDescription'],inplace=True)
            trsPreMapped = mu.appendMatchedColumns(srcMap=trsPreMapped,destMap=trsDestMap,left="datimCategoryOptionCombo",right="categoryOptionCombo_name",columnName=["indicator_replaced","indicatorSchema"],match='replace')

            trsPreMapping = hu.combineData(trsPreMapped,data=trsCatDestMap,leftColumns=['categoryOptionComboMatch'],rightColumns=['disaggregationName'])
            trsPreMappedOptionCombo = mu.appendMatchedColumns(srcMap=trsPreMapping,destMap=trsDestMap,dataElement='dataElement_id',optionCombo='indicator_replaced',check='id',columnName=["formula","formulaSchema"])
            trsMap = mu.appendMatchedColumns(srcMap=trsPreMappedOptionCombo,destMap=trsIndDestMap,check='indicator_replaced',dataElement='numerator',match='compare',columnName=["indicator_id","refIndicatorName","refIndicatorDenominator","refIndicatorCategory","refIndicatorNumerator","indicatorMatch",'categoryType'],fields=['id','name','denominator','indicatorGroups_name'])
            trsMapping = mu.createMapping(sourceMap=trsMap,category='dataelement',resourceType='trs',authority='datim',map=False,platform='dhis2')
            trsMappingFilter = trsMapping.filter(filterColumns)
            hu.createResultFile(trsMappingFilter,'zmdhis','zm_echo_mapping_trs','csv')
            #startImport.createResultFile(trsMappingFilter,'zmdhis','zm_mapping_trs','json')
            print("Updating datastore")
            api.updateDHIS2Item(secrets['zmdhis']['url'],session,'dataStore/terminology/mapping',json.loads(trsMappingFilter.to_json(orient='records')))
    else:
        pass

if __name__ == "__main__":
    main(sys.argv[1:])
