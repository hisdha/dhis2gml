import getGesisDhis2 as gesisd
import sys,argparse
import json,bunch
import numpy as np, pandas as pd

def main(argv):
    parser = argparse.ArgumentParser(description="Importing Gesis data - Access database")
    parser.add_argument("-l","--secrets",help="Specify file (json)")
    parser.add_argument("-s","--streaming",help="Stream online via Web API")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-pf","--filterParams",help="Specify filters parameters e.g id,code,name")
    parser.add_argument("-i","--indicators",help="process indicators")
    parser.add_argument("-d","--download",help="download data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    parser.add_argument("-dm","--destMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    parser.add_argument("-sm","--srcMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    args = parser.parse_args()
    ggd = gesisd.getGesisDHIS2()
    secrets = ggd.getAuth()
    session = ggd.getLoginSession(secrets['zmdhis']['username'],secrets['zmdhis']['password'],sid='DHIS2')
    params = {"paging":"false","fields":"id,name,code"}
    ouParams = {"paging":"false","fields":"id,name,code,description,ancestors[id,level,name]","filter":["ancestors.name:ilike:Zambia","level:eq:6"]}
    filteredParams = {"paging":"false","fields":"id,name,level,code,ancestors[id,name,code,level,]","filter":"name:ilike:delete"}
    fileName = args.fileName
    if args.params is not None:
        params = args.params
    if args.filterParams is not None:
        filteredParams = args.filterParams
    if args.coding == "lrs":
        if args.streaming is None:
            if args.fileName is None:
                raise sys.exit('Please provide HFR CSV file')
            # OrganisationUnits mapping (only for Zambia)
            ohaCsvOrgUnits = ggd.getPdFile(fileName=fileName,type='csv',folder='hfr',replaceNull=True)
            #ohaCsvOrgUnits.loc[:,'zpctCode'] = ohaCsvOrgUnits['zpctCode'].map(str)
            #ohaCsvOrgUnits.loc[:,'dhis2Code'] = ohaCsvOrgUnits['dhis2Code'].map(str)
            ohaCsvOrgUnits.loc[:,'category'] ='ORGUNIT'
            ohaCsvOrgUnits.loc[:,'type'] = 'facility'
            ohaCsvOrgUnits.loc[:,'level'] = '6'
            ohaCsvOrgUnits.loc[:,'resourceType'] = 'FRS'
            ohaCsvOrgUnits.loc[:,'frsSourceSystem'] = 'DHIS2'
            ohaCsvOrgUnits.loc[:,'categoryType'] = ''
            ohaCsvOrgUnits.loc[:,'active'] = True
            zmOrgUnits= ggd.getDHIS2OrgUnits(secrets['zmdhis']['url'],session,params=ouParams)
            trsZmOrgUnits = ggd.transformJson(zmOrgUnits)
            ohaOrgUnits = ggd.getPdFile(type='json',values=trsZmOrgUnits)
            ohaOuMap = ggd.combineDataValues(ohaCsvOrgUnits,data=ohaOrgUnits,leftColumns=['id'],rightColumns=['id'])
            ggd.createResultFile(ohaOrgUnits,'hfr','{}_{}'.format(fileName,'zm_oha_current_moh_mfl'),'csv')
            #ggd.createResultFile(ohaOuMap,'hfr','{}_{}'.format(fileName,'oha_current_ou_map'),'csv')
            ggd.updateDHIS2Item(secrets['zmdhis']['url'],session,'dataStore/frs/zm',json.loads(ohaCsvOrgUnits.to_json(orient='records')))
    else:
        pass

if __name__ == "__main__":
    main(sys.argv[1:])
