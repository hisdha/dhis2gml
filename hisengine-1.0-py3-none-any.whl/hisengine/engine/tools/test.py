import hisApi as ha
import sys,argparse
import json,bunch

def main(argv):
    parser = argparse.ArgumentParser(description="Manipulate DHIS2 Users")
    parser.add_argument("-l","--secrets",help="Specify file (json)")
    parser.add_argument("-s","--streaming",help="Stream online via Web API")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-d","--download",help="download data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    args = parser.parse_args()
    ggd = ha.hisApi()
    secrets = ggd.getAuth()
    session = ggd.getLoginSession(secrets['dtal']['username'],secrets['dtal']['password'],sid='DHIS2')
    print("Session",session)

if __name__ == "__main__":
    main(sys.argv[1:])
