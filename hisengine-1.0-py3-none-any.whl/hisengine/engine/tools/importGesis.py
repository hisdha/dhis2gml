import getGesisDhis2 as gesisd
import sys,argparse

def main(argv):
    parser = argparse.ArgumentParser(description="Importing Gesis data - Access database")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-pf","--filterParams",help="Specify filters parameters e.g id,code,name")
    parser.add_argument("-i","--indicators",help="process indicators")
    parser.add_argument("-d","--data",help="process data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--file",help="main file with data  or substring")
    parser.add_argument("-md","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    parser.add_argument("-dm","--destMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    parser.add_argument("-sm","--srcMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    args = parser.parse_args()
    startImport= gesisd.getGesisDHIS2()
    secrets = startImport.getAuth()
    params = {"paging":"false","fields":"id,name,code"}
    filteredParams = {"paging":"false","fields":"id","filter":"ancestors.id:in:[HurBrymbN1S,OLNpyBROkUv]"}
    if args.params is not None:
        params = args.params
    if args.filterParams is not None:
        filteredParams = args.filterParams
    if args.coding == "lrs":
        startImport.createMapping(sourceMap=zmJsonOrgUnits,destinationMap=dfSystem2,mappings=[{'old':code,'new':'dhis2Code'},{'old':'id','new':'dhis2Id'},{'old':'name','new':'dhis2Name'}],leftColumns=['cCodeStru'],rightColumns=['code'],category='ORGUNIT',resourceType='frs',authority='DHIS2')
    if args.coding == "trs":
        zmdataElements = startImport.getPdFile(fileName='datim_dataelement_mapping',type='csv',folder='zmdhis')
        zmDeMapping = startImport.createMapping(sourceMap=zmdataElements,category='DATALEMENT',resourceType='trs',authority='dhis2',map=False,categoryType='optionCombo')
        startImport.createResultFile(zmDeMapping,'zmdhis','zm_mapping_dataelements','csv')
        startImport.createResultFile(zmDeMapping,'zmdhis','zm_mapping_dataelements','json')
        startImport.updateDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataStore/terminology/indicators',json.loads(zmDeMapping.to_json(orient='records')))
    else:
        pass



    #zmparams = {"paging":"false","fields":"id,name,code,ancestors[id,name]"}
    #zmOrgUnits = startImport.getDHIS2OrgUnits(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],params=zmparams)

    mgOrgUnits= startImport.getDHIS2OrgUnits(secrets['dhis']['url'],secrets['dhis']['username'],secrets['dhis']['password'],params=params)
    mgOrgUnitsx= startImport.getDHIS2OrgUnits(secrets['dhis']['url'],secrets['dhis']['username'],secrets['dhis']['password'],params=filteredParams)



    #dfSystem2 = startImport.getPdFile('datim_orgunit_mapping.csv','csv','zmdhis')
    #zmJsonOrgUnits = startImport.getPdFile(type='json',values=zmOrgUnits)
    #zmOuMapping = startImport.createMapping(sourceMap=zmJsonOrgUnits,destinationMap=dfSystem2,mappings=[{'old':code,'new':'dhis2Code'},{'old':'id','new':'dhis2Id'},{'old':'name','new':'dhis2Name'}],leftColumns=['cCodeStru'],rightColumns=['code'],category='ORGUNIT',resourceType='FRS',authority='DHIS2')
    #startImport.createResultFile(zmOuMapping,'zmdhis','zm_mapping_orgunits','csv')
    #startImport.updateDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataStore/frs/zm',json.loads(zmOuMapping.to_json(orient='records')))




    #mgJsonOrgUnits = startImport.getPdFile(fileName='oumapgesis',type='csv',folder='gesis')
    #inputOrgUnits = startImport.getPdFile(fileName='mg_map_orgunits',type='csv',folder='gesis')
    #mgJsonOrgUnits = startImport.getPdFile(type='json',values=mgOrgUnits)
    #analyzedDupOrgUnits = startImport.analyzeDuplicates(source=mgJsonOrgUnits,validate=inputOrgUnits,type='csv',rightColumns=['code'],leftColumns=['code'])
    #analyzedDupOrgUnits['duplicated'] = analyzedDupOrgUnits.apply(lambda row: row['code'] != row['code'],axis=1)
    #analyzedNoDupOrgUnits = startImport.analyzeDuplicates(source=mgJsonOrgUnits,validate=inputOrgUnits,type='csv',columns=['code'],duplicated='remove',dupColumns=['uid','id'])
    #startImport.createResultFile(analyzedDupOrgUnits,'gesis','mg_duplicatedx_orgunits','csv')
    #startImport.createResultFile(analyzedNoDupOrgUnits,'gesis','mg_existing_dup_orgunits','csv')

    	# Get import data for DHIS2
    mainDataFile = 'dataBeyondApril'
    dataElementMappingFile = 'dataElementMapping'

    print("Retrieving orgunits from server")
    mgImportOrgUnits = startImport.getPdFile(type='json',values=mgOrgUnits)
	mgImportOrgUnitsx = startImport.getPdFile(type='json',values=mgOrgUnitsx)
	dataElements = startImport.getPdFile(fileName=dataElementMappingFile,type='csv',folder='gesis')
    print("Spliting files")
	dtFileNames = startImport.splitFile(fileName=mainDataFile,type='csv',folder='gesis/dataBeyond',chunksize=100000,chunkType='files',columns='cCode',dropColumns=['cType','cCode'])
    for dataFile in dtFileNames:
        print("Data File processing : ",dataFile)
		dataValueSet = startImport.getPdFile(fileName=dataFile,type='csv',folder='gesis/dataBeyond',addFileExt=False)
    	df = startImport.createDataValueSet(dataValueSet,year='cAnnee',month='cPeriode',idVars=['cAnnee','cPeriode','cCodeNiv','cCodeStru','cTypeRapport','period'],valueVars=['cAnnee','cPeriode','cCodeNiv','cCodeStru','cTypeRapport','period'])
    	# Filter out all rows without data and rows that have zero.
    	cleanedDf = df.query('value != ""')
    	cleanedDfNoZero = cleanedDf[cleanedDf['value'] > '0.0']
    	dataSetDataElements = dataElements.query("gesisDataSet == @dataFile")
    	# Combine data elements to datavalues
    	dataValues = startImport.combineDataValues(cleanedDfNoZero,data=dataSetDataElements,leftColumns=['fieldname'],rightColumns=['gesisCode'])
    	startImport.createResultFile(dataValues,'gesis','mg_import_dataValues','csv')
	mgImportOrgUnitsxx = startImport.renameColumns(data=mgImportOrgUnitsx,columns={'id':'aid'})
	dataValueSetF = startImport.combineDataValues(dataValueSet,data=mgImportOrgUnitsxx,leftColumns=['id'],rightColumns=['aid'])
    	# Save all data
    	dataValueSet['attributeOptionCombo']='HllvX50cXC0'
    	dataValueSet['storedby']='imported'
    	startImport.createResultFile(dataValueSet,'gesis','{}_{}'.format('mg_import_dataValueSet',dataFile),'csv')
    	# Get all data which is beyond June,2018
    	#dataValueSet_dataBeyondJune = dataValueSet.query('period >= "201805"')
    	#startImport.createResultFile(dataValueSet_dataBeyondJune,'gesis','{}_{}'.format('mg_import_dataValueSet_dataBeyondApril',dataFile),'csv')
    	# Get all data which is not matched in the ancestors
    	dataValueSet_ouNotMatchedR = dataValueSetF[dataValueSetF['aid'].isnull()]
    	# Get all data whose orgunit did not match
    	dataValueSet_ouNotMatched = dataValueSet_ouNotMatchedR[dataValueSet_ouNotMatchedR['code'].isnull()]
    	startImport.createResultFile(dataValueSet_ouNotMatched,'gesis/dataBeyondt','{}_{}'.format('mg_import_dataValueSet_ouNotMatched',dataFile),'csv')
    	# Get all data whose orgunit matched.
    	dataValueSet_ouMatched = dataValueSet_ouNotMatchedR[dataValueSet_ouNotMatchedR['code'].notnull()]
    	#startImport.createResultFile(dataValueSet_ouMatched,'gesis','{}_{}'.format('mg_import_dataValueSet_ouMatched',dataFile),'csv')
    	## All cleaned data with data non matched facilities, periods beyond June excluded.
    	dataValueSet_cleaned = dataValueSet_ouMatched.query('period >= "201805"')
    	#startImport.createResultFile(dataValueSet_cleaned,'gesis','{}_{}'.format('mg_import_dataValueSet_cleaned',dataFile),'csv')

    	mgAggregateData = startImport.createDHIS2AggregateDataImport(data=dataValueSet_cleaned,columns=["dataelement","period","orgunit","catoptcombo","attroptcombo","value","storedby","lastupd","comment"])
    	mgAggregateData = startImport.createDHIS2AggregateDataImport(data=dataValueSet_ouMatched,columns=["DataElementId","period","id","categoryOptionCombo","attributeOptionCombo","value","storedby"])
    	mg_importData = startImport.renameColumns(data=mgAggregateData,columns={'id':'orgUnitId'})
    	mg_importData["value"] = pd.to_numeric(mg_importData["value"])
    	startImport.createResultFile(mg_importData,'gesis/dataBeyondt','{}_{}'.format('mg_import_dataValueSet_aggregate',dataFile),'csv')
    	#startImport.createResultFile(importData,'gesis','mg_import_dataValueSet_renamed','csv')
