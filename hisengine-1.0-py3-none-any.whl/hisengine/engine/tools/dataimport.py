import getGesisDhis2 as gesisd
import sys,argparse

def main(argv):
    parser = argparse.ArgumentParser(description="Importing Gesis data - Access database")
    parser.add_argument("-p","--params",help="Specify parameters e.g id,code,name")
    parser.add_argument("-pf","--filterParams",help="Specify filters parameters e.g id,code,name")
    parser.add_argument("-i","--indicators",help="process indicators")
    parser.add_argument("-d","--download",help="download data")
    parser.add_argument("-t","--transposeData",help="transpose data")
    parser.add_argument("-a","--authFile",help="Authentication file")
    parser.add_argument("-m","--mappingFile",help="code mapping list")
    parser.add_argument("-f","--fileName",help="main file with data  or substring")
    parser.add_argument("-c","--coding",help="map data elements/codes to other systems")
    parser.add_argument("-r","--type",help="type of metadata")
    parser.add_argument("-dm","--destMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    parser.add_argument("-sm","--srcMap",help="Destination mapping e.g [{'old':code,'new':'dhis2Code'}]")
    args = parser.parse_args()
    startImport= gesisd.getGesisDHIS2()
    secrets = startImport.getAuth()
    params = {"paging":"false","fields":"id,name,code"}
    filteredParams = {"paging":"false","fields":"id","filter":"ancestors.id:in:[HurBrymbN1S,OLNpyBROkUv]"}
# Start the idsr processing
if __name__ == "__main__":

	startImport= getGesisDHIS2()
	secrets = startImport.getAuth()
	params = {"paging":"false","fields":"id,name,code"}
	filteredParams = {"paging":"false","fields":"id,name,code","filter":"ancestors.id:!in:[HurBrymbN1S,OLNpyBROkUv]"}
	#zmparams = {"paging":"false","fields":"id,name,code,ancestors[id,name]"}
	#zmOrgUnits = startImport.getDHIS2OrgUnits(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],params=zmparams)

	mgOrgUnits= startImport.getDHIS2OrgUnits(secrets['dhis']['url'],secrets['dhis']['username'],secrets['dhis']['password'],params=params)
	mgOrgUnitsx= startImport.getDHIS2OrgUnits(secrets['dhis']['url'],secrets['dhis']['username'],secrets['dhis']['password'],params=filteredParams)



	#dfSystem2 = startImport.getPdFile('datim_orgunit_mapping.csv','csv','zmdhis')
	#zmJsonOrgUnits = startImport.getPdFile(type='json',values=zmOrgUnits)
	#zmOuMapping = startImport.createMapping(sourceMap=zmJsonOrgUnits,destinationMap=dfSystem2,mappings=[{'old':code,'new':'dhis2Code'},{'old':'id','new':'dhis2Id'},{'old':'name','new':'dhis2Name'}],leftColumns=['cCodeStru'],rightColumns=['code'],category='ORGUNIT',resourceType='FRS',authority='DHIS2')
	#startImport.createResultFile(zmOuMapping,'zmdhis','zm_mapping_orgunits','csv')
	#startImport.updateDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataStore/frs/zm',json.loads(zmOuMapping.to_json(orient='records')))

	#zmdataElements = startImport.getPdFile(fileName='datim_dataelement_mapping',type='csv',folder='zmdhis')
	#zmDeMapping = startImport.createMapping(sourceMap=zmdataElements,category='DATALEMENT',resourceType='TS',authority='DHIS2',map=False)
	#startImport.createResultFile(zmDeMapping,'zmdhis','zm_mapping_dataelements','csv')
	#startImport.createResultFile(zmDeMapping,'zmdhis','zm_mapping_dataelements','json')
	#startImport.updateDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataStore/terminology/indicators',json.loads(zmDeMapping.to_json(orient='records')))


	#mgJsonOrgUnits = startImport.getPdFile(fileName='oumapgesis',type='csv',folder='gesis')
	#inputOrgUnits = startImport.getPdFile(fileName='mg_map_orgunits',type='csv',folder='gesis')
	#mgJsonOrgUnits = startImport.getPdFile(type='json',values=mgOrgUnits)
	#analyzedDupOrgUnits = startImport.analyzeDuplicates(source=mgJsonOrgUnits,validate=inputOrgUnits,type='csv',rightColumns=['code'],leftColumns=['code'])
	#analyzedDupOrgUnits['duplicated'] = analyzedDupOrgUnits.apply(lambda row: row['code'] != row['code'],axis=1)
	#analyzedNoDupOrgUnits = startImport.analyzeDuplicates(source=mgJsonOrgUnits,validate=inputOrgUnits,type='csv',columns=['code'],duplicated='remove',dupColumns=['uid','id'])
	#startImport.createResultFile(analyzedDupOrgUnits,'gesis','mg_duplicatedx_orgunits','csv')
	#startImport.createResultFile(analyzedNoDupOrgUnits,'gesis','mg_existing_dup_orgunits','csv')

 	# Get import data for DHIS2
	mainDataFile = 'tRM_CSB_Cons_Ext'
	dataElementMappingFile = 'dataElementMapping'

	print("Retrieving orgunits from server")
	mgImportOrgUnits = startImport.getPdFile(type='json',values=mgOrgUnits)
	mgImportOrgUnitsx = startImport.getPdFile(type='json',values=mgOrgUnitsx)
	dataElements = startImport.getPdFile(fileName=dataElementMappingFile,type='csv',folder='gesis')
	print("Spliting files")
	dtFileNames = startImport.splitFile(fileName=mainDataFile,type='csv',folder='gesisNew',chunksize=200000,chunkType='column',columns='cCode',dropColumns=['cType','cCode'])
	for dataFile in dtFileNames:
		print("Data File processing : ",dataFile)
		dataValueSet = startImport.getPdFile(fileName=dataFile,type='csv',folder='gesisNew',addFileExt=True)
		if dataValueSet.empty:
			print("Data file has no data")
		else:
			df = startImport.createDataValueSet(dataValueSet,year='cAnnee',month='cPeriode',idVars=['cAnnee','cPeriode','cCodeNiv','cCodeStru','cTypeRapport','period'],valueVars=['cAnnee','cPeriode','cCodeNiv','cCodeStru','cTypeRapport','period'])
			# Filter out all rows without data and rows that have zero.
			cleanedDf = df.query('value != ""')
			cleanedDfNoZero = cleanedDf[cleanedDf['value'] > '0.0']
			noExtDataFile = os.path.splitext(dataFile)[0]
			#noExtDataFile = 'tRM_CSB_Cons_Ext'
			dataSetDataElements = dataElements.query("gesisDataSet == @noExtDataFile")
			# Combine data elements to datavalues
			dataValues = startImport.combineDataValues(cleanedDfNoZero,data=dataSetDataElements,leftColumns=['fieldname'],rightColumns=['gesisCode'])
			#startImport.createResultFile(dataValues,'gesis','mg_import_dataValues','csv')
			#mgImportOrgUnitsxx = startImport.renameColumns(data=mgImportOrgUnitsx,columns={'id':'aid'})
			dataValueSetF = startImport.combineDataValues(dataValues,data=mgImportOrgUnitsx,leftColumns=['cCodeStru'],rightColumns=['code'])
			# Save all data
			dataValueSetF['attributeOptionCombo']='HllvX50cXC0'
			dataValueSetF['storedby']='imported'
			#startImport.createResultFile(dataValueSet,'gesis','{}_{}'.format('mg_import_dataValueSet',dataFile),'csv')
			# Get all data which is beyond June,2018
			dataValueSet_dataBeyondJune = dataValueSetF.query('period >= "201805"')
			#startImport.createResultFile(dataValueSet_dataBeyondJune,'gesisNew/data','{}_{}'.format('mg_import_dataValueSet_dataBeyondApril',dataFile),'csv')
			# Get all data which is not matched in the ancestors
			#dataValueSet_ouNotMatchedR = dataValueSet_dataBeyondJune[dataValueSet_dataBeyondJune['id'].isnull()]
			# Get all data whose orgunit did not match
			#dataValueSet_ouNotMatched = dataValueSet_ouNotMatchedR[dataValueSet_ouNotMatchedR['code'].isnull()]
			#startImport.createResultFile(dataValueSet_ouNotMatched,'gesisNew/dataBeyondtNew','{}_{}'.format('mg_import_dataValueSet_ouNotMatched',dataFile),'csv')
			# Get all data whose orgunit matched.
			dataValueSet_ouMatched = dataValueSet_dataBeyondJune[dataValueSet_dataBeyondJune['code'].notnull()]
			#startImport.createResultFile(dataValueSet_ouMatched,'gesis','{}_{}'.format('mg_import_dataValueSet_ouMatched',dataFile),'csv')
			## All cleaned data with data non matched facilities, periods beyond June excluded.
			#dataValueSet_cleaned = dataValueSet_ouMatched.query('period < "201805"')
			#startImport.createResultFile(dataValueSet_cleaned,'gesis','{}_{}'.format('mg_import_dataValueSet_cleaned',dataFile),'csv')

			#mgAggregateData = startImport.createDHIS2AggregateDataImport(data=dataValueSet_cleaned,columns=["dataelement","period","orgunit","catoptcombo","attroptcombo","value","storedby","lastupd","comment"])
			mgAggregateData = startImport.createDHIS2AggregateDataImport(data=dataValueSet_ouMatched,columns=["DataElementId","period","id","categoryOptionCombo","attributeOptionCombo","value","storedby"])
			mg_importData = startImport.renameColumns(data=mgAggregateData,columns={'id':'orgUnitId'})
			#mg_importData["value"] = pd.to_numeric(mg_importData["value"])
			startImport.createResultFile(mg_importData,'gesisNew/data','{}_{}'.format('mg_import_dataValueSet_aggregate',dataFile),'csv')
			#startImport.createResultFile(importData,'gesis','mg_import_dataValueSet_renamed','csv')

	## Get DHIS2 indicators
	#By female
	#indparams ={"paging":"false","fields":"id,name,shortName,denominator,denominatorDescription,decimals,numerator,numeratorDescription,indicatorType[id]","filter":["name:ilike$:total female","name:!$like:VCT:","name:!$like:MC:","name:!$like:LAB:","name:!$like:PMTCT:","name:!$like:INFANT:"]}
	#indicators = startImport.getDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'indicators',params=indparams)
	#alteredIndicators = startImport.createDHIS2Indicators(values=indicators['indicators'],testField='name',field='numerator',searchText='total female',replacementText='lh35x8ciyal',multiple=False,replace=True)
	#zmalteredIndicators = startImport.getPdFile(type='json',values=alteredIndicators)
	#startImport.createResultFile(zmalteredIndicators,'zmdhis','zm_indicators_female','json')

	#Create indicators by female
	#fparams ={"paging":"false","fields":"id,name,code,shortName","filter":"id:in:[P7bw7DQfnQw,QavztSUobah,PPFp0lw0a9h,EICaImDQjNZ,UoJs4uCKqsh,Aiz0BZ5Sp9y]"}
	#fdataElements = startImport.getDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataElements',params=fparams)
	#newIndicators = startImport.createDHIS2Indicators(searchText='total female',replace=False,uids=["m6nPtMJU3Ws","Hm3AypJKkga","NShQNnz5YGA","pwZrWbMOuY7","UCy9b5eis4G","mnc69f3ITI5"],elements=fdataElements['dataElements'],options=["mt4lYKwt5A7","h12bB8tBP3m","tq5nmXb1d6k","c5CAsYlTUtW","ZMHX9mkFdis","cAtVNvfofIt","XPNBVnFgjVl","NhcE9QtsGXH","BcIOEd26TzD","TkNy22uDXzK","SZo7TFizoXV","lh35x8ciyal"])
	#zmnewIndicators = startImport.getPdFile(type='json',values=newIndicators)
	#startImport.createResultFile(zmnewIndicators,'zmdhis','zm_new_indicators_female','json')

	#Create indicators by male and female
	#mparams ={"paging":"false","fields":"id,name,code,shortName","filter":"id:in:[IW1aidWO5OL]"}
	#fdataElements = startImport.getDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataElements',params=mparams)

	#newIndicators = startImport.createDHIS2Indicators(searchText='total female',replace=False,uids=["WxHwVBP6fwO"],elements=fdataElements['dataElements'],options=["mt4lYKwt5A7","h12bB8tBP3m","tq5nmXb1d6k","c5CAsYlTUtW","ZMHX9mkFdis","cAtVNvfofIt","XPNBVnFgjVl","NhcE9QtsGXH","BcIOEd26TzD","TkNy22uDXzK","SZo7TFizoXV","lh35x8ciyal"])
	#zmnewIndicators = startImport.getPdFile(type='json',values=newIndicators)
	#startImport.createResultFile(zmnewIndicators,'zmdhis','zm_new_indicators_female_prep9','json')

	#Create indicators by initial, follow up and routine revisits totals
	mcparams ={"paging":"false","fields":"id,name,code,shortName,categoryCombo[categoryOptionCombos[id,name]]","filter":"id:in:[TzfsjVkSo9E,WBsVSAzKsjj]"}
	fcdataElements = startImport.getDHIS2Item(secrets['zmdhis']['url'],secrets['zmdhis']['username'],secrets['zmdhis']['password'],'dataElements',params=mcparams)

	newcIndicators = startImport.createDHIS2Indicators(searchText='total',replace=False,uids=["J7onrsrCagW",
    "HkQaYU34qKe",
    "QuuWoFhThTz",
    "OYhfEjTPxAg",
    "FNPHo2kc2fR",
    "sSPiOzT3wrA",
    "aZeshyYSawJ",
    "EG3GRdlWTwH",
    "rjFYJf3BkeI",
    "aBP083V1fg6",
    "q7RCKviNj7U",
    "DemPzvXxWLU",
    "Cu4EVIfSuuT",
    "rjmaCVXi33z",
    "M8yGlAinQhn",
    "BuebzkUt7Q4",
    "dRpSxdWVi8t",
    "rT4BRAAuivS",
    "xajKwfgGjSu",
    "uUrSFI2Xxwn",
    "e0GfuGnQlV8",
    "oLAFQXltn4T",
    "JlAAfLHyoWc",
    "Q5tiaRmMwlA",
    "GTJJrbiqHvq",
    "uzdOimoiPcp",
    "EloOYS5KHsU"],elements=fcdataElements['dataElements'],options=["eTpYMIHyxKn",
"pUUKpmcbCe1",
"KVuNBxh4zqB",
"fpmiLVf9Gsn",
"hXrEeEbjyxS",
"ul4P6FLogrV",
"uBsH3NpcOw8",
"u15ltP5BhK4",
"frq2WvYzWdR",
"qLKdb5vOsmq",
"FZNfMqIFZ0J",
"BelXeMJPOQn",
"NDUikSBFmGK",
"oDNu4kUdXSi",
"FUplpoQ6B7j",
"bBOse9IolBM",
"rH9kBzm8u52",
"fjYAXGTXwm1",
"rLFNsVIET5u",
"wM5iZ83yvZU",
"jnQcegw6xR7",
"mGQIzRtheuW",
"sav7dgFHtsb",
"wZgBKbV61l5",
"O6ePuEHobVS",
"jKkCxRlC2Yi",
"HiAKRyrFkmE"],prefix="CECAP3 Age",axis=1)
	#zmcnewIndicators = startImport.getPdFile(type='json',values=newcIndicators)
	#startImport.createResultFile(zmcnewIndicators,'zmdhis','zm_new_indicators_cancer_total_part6','json')

	#mnewIndicators = startImport.createDHIS2Indicators(searchText='total male',replace=False,uids=["LVr3snazuL9"],elements=fdataElements['dataElements'],options=["cN7C77eDU4T","qysh66vHfzU","k3mj1XMi7zE","cdngY4ErqrD","RL75GkEjc3x","c35PoteTj3B","eQzgD8Gw9sf","bS4PCfznJzX","VA1R3jxoGbc","Xu1dTz1USeQ","ue72o19kSkn","Ie0F2MhnHWc"])
	#zmmnewIndicators = startImport.getPdFile(type='json',values=mnewIndicators)
	#startImport.createResultFile(zmmnewIndicators,'zmdhis','zm_new_indicators_male_prep9','json')

	#Create indicators for Mg-total Homme
	#mparams ={"paging":"false","fields":"id,name,code,shortName,categoryCombo[categoryOptionCombos[id,name]]","filter":"id:in:[R0w2W8OCDqM,YbiOMMnxUrS,GNas9mLa1V5,kcyY7fmknGo,faIPttrGX7Y]"}
	#fdataElements = startImport.getDHIS2Item(secrets['gesis']['url'],secrets['gesis']['username'],secrets['gesis']['password'],'dataElements',params=mparams)

	#newIndicators = startImport.createDHIS2Indicators(prefix='',indicatorTypeId="sH6aUxyd0ld",searchText='3 Total',replace=False,uids=["exWlIC8bYIY",
#"yFbTcSouXTp",
#"gdvwZoNmAIN",
#"U12EkZh4S3j",
#"bXd0fzomio1"],elements=fdataElements['dataElements'],options=["ZxGmRQQXYvG",
#"Y1INq3Ht9JG",
#"PGeiu1kba3v"],axis=0)
	#zmnewIndicators = startImport.getPdFile(type='json',values=newIndicators)
	#startImport.createResultFile(zmnewIndicators,'gesis','mg_new_indicators_t14_3_total','json')

	#fnewIndicators = startImport.createDHIS2Indicators(indicatorTypeId="sH6aUxyd0ld",searchText='total Homme',replace=False,uids=["wz8PTEAHNJV","GRU1a0Bv2bH","EuLfm8QgJ6e","bgQJI1eVzWT","mQ5TWXT5P7F","JCYnf8aBpfK"],elements=fdataElements['dataElements'],options=["hG2mDTfOolJ", "DUr35AVUKnz", "VNrll00VDSq", "DMPLpfaNxMr", "GL1LgKYMBvm", "prZU7TdX7vF", "iFzeyjfMf8k"])
	#fzmnewIndicators = startImport.getPdFile(type='json',values=fnewIndicators)
	#startImport.createResultFile(fzmnewIndicators,'gesis','mg_new_indicators_t6_Femme','json')

#main()
