# -*- coding: utf-8 -*-
# Facility Registry Service
# Creates facility registry from systems delegated as Master based on openHIE architecture
#

from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
import json,bunch,uuid
import riak,pandas as pd, jellyfish as jf

from urllib.parse import parse_qs
# Custom services
#import database
# Zato
from zato.server.service import Service

class CreateLocationRegistry(Service):
    """ Creates Master Location Registry endpoint.
    """
    #class SimpleIO:
    #    output_optional = ('organisationUnits')
     #   input_required = ('dataType','serviceType')
      #  output_repeated = True

    def handle(self):

        # Python dict representing the payload we want to send across
        payload = {}
        kvService = 'zato.kvdb.data-dict.dictionary.get-key-list'
        kvRequest = {'system':'System','key':'config'}
        kvResponse = self.invoke(kvService, kvRequest)
        self.logger.info(kvResponse)
        kvConfig = self.kvdb.conn.get('config')
        self.logger.info('key:[{}]'.format(kvConfig))
        print("Key : ", kvConfig)
        # Create/update configuration
        config = {}

        # Python dict with all the query parameters, including path and query string
        params = {}
        # Metadata mapping
        tsMappings ={
            "types":[{"id":1,"name":"disaggregation"},{"id":2,"name":"indicator"},{"id":3,"name":"attribute"}],
            "groups":[{"id":1,"group":"ART","type":"indicator","category":"HIV","system":1},{"id":2,"group":"HTS_TST","type":"indicator","category":"HIV","system":1}
          ],
            "mappings":[]
        }

        # Headers the endpoint expects
        headers = {'X-Service': 'Location Registry', 'X-Version':'Production'}

        # Obtains a DHIS2 connection object
        frsConnection = self.outgoing.plain_http.get('LocationRegistryService')

        ## Get connection to Riak Database
        riak_frs = self.connect('riakcoordinator.dev.svc.cluster.local',8087,'integration')
        # save configuration to database
        self.saveItem(riak_frs,'config',config)
        self.logger.info("Configuration saved")
        riak_configs = self.getItems(riak_frs,'config')
        self.saveItem(riak_frs,'tsMappings',tsMappings)
        # Invoke the resource providing all the information on input
        # response = frsConnection.conn.post(self.cid, payload, params, headers=headers)
        qs =parse_qs(self.wsgi_environ['QUERY_STRING'])
        serviceType1 = 'lrs'
        dataType = 'json'



        if serviceType1 == 'lrs':
            params = {'apiVersion':'29','resourceName': 'organisationUnits','fields':'id,code,name,openingDate,closedDate,coordinates,ancestors[level,id,code,name],organisationUnitGroups[name]','paging':'false'}
            response = frsConnection.conn.get(self.cid,params=params)

            organisationUnits = self.transformJson(valueSet=json.loads(response.text),sourceType='dhis2')
            self.saveItem(riak_frs,'organisationUnits',organisationUnits)
            riak_data = self.getItems(riak_frs,'organisationUnits')
            self.response.payload =  bunch.bunchify(riak_data)
        elif serviceType1 == 'ts':
            params = {'apiVersion':'29','resourceName': 'dataElements','fields':'id,code,name,dataElementGroups[id,name]'}
            response = frsConnection.conn.get(self.cid,params=params)
            tsNewMappings = bunch.bunchify(response.text)
            riak_mappings = self.getItems(riak_frs,'tsMappings')
            if len(riak_mappings['mappings']) == 0:
                tsMappings['mappings'] = tsNewMappings
                self.saveItem(riak_frs,'tsMappings',tsMappings)
            else:
                # Check if an element exist
                nonExistingElements = []
                for el in tsNewMappings['dataElements']:
                    elemExist = self.elementExists(el,tsNewMappings['dataElements'])
                    if not elemExist:
                        nonExistingElements.append(el)
                riak_mappings['mappings'].extend(nonExistingElements)
                ### manipulate data elements for Terminology Service
                tsParams = riak_configs['dhis2ids']
                datimPublicElements = getDATIMDataElements(tsParams['results'])
                riak_mappings['mappings'].extend(datimPublicElements)
                self.saveItem(riak_frs,'terminology',riak_mappings)
            riak_data = self.getItems(riak_frs,'tsMappings')
            self.response.payload =  bunch.bunchify(riak_data)
        else:
            #pass
            self.logger.info("query",self.request)
            #self.logger.info(organisationUnits)
            response = frsConnection.conn.get(self.cid,params=params)
            self.response.payload = []
        self.response.content_type='application/json'


    def createOrgUnitList(self,orgunits):
        ouList = {}
        orgUnitList = []
        ouList['pager'] = orgunits['pager']
        if len(orgunits['organisationUnits']) > 0:
            for ou in orgunits['organisationUnits']:
                orgUnit = {}
                orgUnit['systemid'] = str(uuid.uuid4())
                orgUnit['identity'] = [{"value":"","type":"code","source":"DHIS2"},{"value":ou['name'],"type":"name","source":"DHIS2"},{"value":ou['id'],"type":"id","source":"DHIS2"}]
                orgUnit['telecom'] = []
                orgUnit['administrativeUnits'] = []
                orgUnit['address'] = []
                orgUnit['endpoint'] = []
                orgUnit['authority'] = [{"value":"","type":"ownership"}]
                orgUnit['status'] = [{"value":"","type":"regulatory"},{"value":"","type":"operating"},{"value":"","type":"validity"},{"value":"","type":"activity"}]
                orgUnit['coordinates'] = [{"value":"","type":"latitude","source":"nbs"},{"value":"","type":"longitude","source":"nbs"}]
                orgUnit['population'] = [{"value":"","type":"catchment","source":"nbs","period":"2004"}]
                orgUnit['tracking'] = [{"value":"","type":"openingdate"},{"value":"","type":"closingdate"},{"value":"","type":"mantainencedate"},{"value":"","type":"nextmantainencedate"}]
                orgUnitGroupInSets = []
                for key,val in ou.items():
                    if key == 'ancestors' and len(ou['ancestors']) > 0:
                        for ancestor in ou['ancestors']:
                            admin = {}
                            adminLevel = '{}{}'.format("level",ancestor['level'])
                            for k,v in ancestor.items():
                                adminUnit = {}
                                if k != 'level':
                                    adminUnit={}
                                    adminUnit['type']=k
                                    adminUnit['value']=ancestor[k]
                                    adminUnit['source'] ="DHIS2"
                                    admin[adminLevel]= adminUnit
                                orgUnit['administrativeUnits'].append(admin)
                    elif key == 'organisationUnitGroups' and len(ou['organisationUnitGroups']) > 0:
                        for ouGroup in ou['organisationUnitGroups']:
                            if key == 'groupSets' and len(ou['groupSets']) > 0:
                                for ouGroupSet in ou['groupSets']:
                                    for ogk,ogv in ouGroupSet.items():
                                        ogGroupUnit = {}
                                        ogGroupUnit['type'] = ogk
                                        ogGroupUnit['value'] = ogv
                                        ogGroupUnit['source']='DHIS2'
                                        orgUnit['authority'].append(ogGroupUnit)
                                    orgUnit[ouGroupSet['name']] = ouGroup['name']
                                    orgUnitGroupInSets.append(ouGroup['name'])
                            else:
                                #orgUnit[ouGroup['name']] = 'Yes'
                                ougGroupUnit = {"identifier":[]}
                                for ougk, ougv in ouGroup.items():
                                    if ougk == 'name':
                                        ougGroupUnit['type'] = ougv
                                        ougGroupUnit['value'] = 'Yes'
                                    elif ougk == 'id':
                                        ougGroupUnit['identifier'].append({'type':ougk,'value': ougv,'system':'DHIS2'})
                                    elif ougk == 'code':
                                        ougGroupUnit['identifier'].append({'type':ougk,'value': ougv,'system':'DHIS2'})
                                    else:
                                        pass
                                ougGroupUnit['system']='DHIS2'
                                orgUnit['authority'].append(ougGroupUnit)
                    else:
                        orgUnit[key] = val
                orgUnitList.append(orgUnit)

        #ouList['organisationUnits'] = sorted(orgUnitList)
        return {'lrs': orgUnitList }
	# Tranform json object or array to flat views
	# @param valueSet - json value set
    def transformJson(self,valueSet=None,sourceType='dhis2'):
        valueSetObject = {'lrs':[]}

        for value in valueSet['organisationUnits']:
            jsonValueSet = {'ref': str(uuid.uuid4()),'resourceType':'location','categoryType':'health','category':'facility','sourceType':sourceType,'authority':'master','value':[]}
            jsonObject ={}
            jsonValueSet['value'].append({ 'type':'mapping','property':'mapping','value':[{'type':'identity','property':'id','ref':'','sourceType':'dhis2'}]})
             #{'tracking':[],'identity':[],'status':[],'address':[],'telecom':[],'authority':{},'regulatory':[],'geocoding':[],'other2':[],'other':[]}
            for key,val in value.items():
                if type(val) is dict:
                    for k,v in val.items():
                        jsonValueSet['value'].append({ 'type':key,'property':key,'value':val})
                elif type(val) is list:
                    for kv in val:
                        if 'level' in list(kv.keys()):
                            for k,v in kv.items():
                                if k != 'level':
                                    levelKey = '{}{}'.format('level',kv['level'])
                                    jsonValueSet['value'].append({'type':'geoLocation','value':{'type': kv['level'],'value':{ 'type':k,'value':v}}})
                                else:
                                    pass
                        else:
                            for k,v in kv.items():
                                jsonValueSet['value'].append({ 'type':v,'value':True})
                else:
                    if key == 'openingDate' or key == 'closedDate':
                        jsonValueSet['value'].append({'type':'tracking','value':{ 'type':key,'property':key,'value':val}})
                    elif key == 'id' or key == 'code' or key == 'name':
                        jsonValueSet['value'].append({'type':'identity','value':{ 'type':key,'property':key,'value':val}})
                    elif key == 'coordinates':
                        jsonValueSet['value'].append({'type':'geocoding','value':{ 'type':key,'property':key,'value':val}})
                    else:
                        jsonValueSet['value'].append({ 'type':key,'property':key,'value':val})
            valueSetObject['lrs'].append(jsonValueSet)
        return valueSetObject
    #Riak Routines
    def connect(self,host, port, bucket):
        self.logger.info("Connecting to Riak Database")
        client = riak.RiakClient(host=host, pb_port=port, protocol='pbc')
        current_bucket = client.bucket(bucket)
        self.logger.info("Connected to the bucket "+ bucket)
        return current_bucket
    def saveItem(self,client,item,items):
        newItem = client.new(item, data=items)
        newItem.store()
        return "Saved"
    def getItems(self,client,items):
        newItem = client.get(items)
        retrievedItem = newItem.data
        return retrievedItem
    def updateItems(self,client,items,itemKey,updateItem):
        newItem = client.get(items)
        newItem.data[itemKey] = updateItem
        newItem.store()

    def sendToRabbitMQ(self,message,sender,reciever):
        print("Sending messages to RabbitMQ")

    def recieveFromRabbitMQ(self,message,sender,reciever):
        print("Recieving messages from RabiitMQ")
    def checkJaroDistance(self,left,right):
        match = (jf.jaro_distance(left,right) * 100)
        fullMatch = False
        if match == 100:
            fullMatch = True
        matchedObject = {"matchValue":match,"matched":fullMatch,"left":left,"right":right}
        return matchedObject

    def createMappings(self,data,refdata,type):
        df = self.createDataFrame(data,type)
        valueMatch = {}
        for index,d in df.iterrows():
            if len(refdata['mappings']) > 0:
                for refd in refdata['mappings']:
                    #valueMatch = self.checkJaroDistance(d['dataelement'],refd['name'])
                    #if valueMatch['matched'] == "true":
                    #    d['matched'] = valueMatch['matched']
                    #    refdata.append(d['map'])
                    #else:
                    #    d['matched'] = valueMatch['matched']
                    refd['name'] = str(d['dataelement'])
                    refd['shortname'] = str(d['shortname'])
                    refd['type'] = 1
                    refd['system'] =1
                    refd['group']= 1
                    refdata['mappings'].append(refd)
                    #refdata.append(d['map'])
            else:
                refd = {}
                #valueMatch = self.checkJaroDistance(d['dataelement'],refd['name'])
                #if valueMatch['matched'] == "true":
                #    d['matched'] = valueMatch['matched']
                #    refdata.append(d['map'])
                #else:
                #    d['matched'] = valueMatch['matched']
                refd['name'] = str(d['dataelement'])
                refd['shortname'] = str(d['shortname'])
                refd['type'] = 1
                refd['system'] =1
                refd['group']= 1
                refdata['mappings'].append(refd)
                #refdata.append(d['map'])
        return refdata
    # Read in Panda file
    def getPdFile(self,fileName,type):
        df = []
        if type == 'csv':
            df = pd.read_csv(fileName,encoding='utf-8')
        elif type == 'json':
            df= pd.read_json(fileName,orient=table)
        else:
            pass
        return df
    # Get DATIM data elements from public repository
    def getDATIMDataElements(self,datasets):
        codes = []
        for das in datasets:
            ds = {'var':'dataSets:'+ das['dataSets']}
            tsResponse = datConnection.conn.get(self.cid,params=ds)
            codes.extend(self.createMappings(json.loads(tsResponse.text),riak_mappings,'None'))
        return codes
    # Check if an element exists
    def elementExists(self,id,values):
        if len(values) > 0:
            for elem in values:
                if elem == id:
                    return True
            return False
        return False

    # create Panda Data Frame from event data
    def createDataFrame(self,events,type):
        cols = self.createColumns(events['headers'],type)
        dataFrame = pd.DataFrame.from_records(events['rows'],columns=cols)
        return dataFrame
    def createColumns(self,data,type):
        cols =[]
        if type == 'AGGREGATE':
            pass
        else:
            for dt in data:
                cols.append(dt['name'])
        return cols
