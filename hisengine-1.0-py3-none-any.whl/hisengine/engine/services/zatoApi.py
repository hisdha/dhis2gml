# -*- coding: utf-8 -*-
# Zato Api Service
# Manipulates Zato Services
#

from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
import json,bunch,uuid
import riak
from urllib.parse import parse_qs
# Zato
from zato.server.service import Service
from zato.client import APIClient

class zatoApi(Service):
    """ Manipulates API services.
    """
    class SimpleIO:
    #    output_optional = ('')
        input_required = ('task','authType')
      #  output_repeated = True

    def handle(self):

        # Python dict representing the payload we want to send across
        payload = {}
        # Create/update configuration
        config = {}

        # Python dict with all the query parameters, including path and query string
        params = {}

        # Headers the endpoint expects
        headers = {'X-Service': 'API service', 'X-Version':'Production'}
        # Store config parameters in Redis
        # @params { username,password}
        authConfig = self.kvdb.conn.get('config')
        client = APIClient(authConfig['address'],authConfig['username'],authConfig['password'])


        # Obtains a DHIS2 connection object
        frsConnection = self.outgoing.plain_http.get('LocationRegistryService')
        datConnection = self.outgoing.plain_http.get('DATIMPublicCodeList')

        ## Get connection to Riak Database
        #riak_frs = self.connect('dhis2.jsi.com',8087,'integration')
        riak_frs = self.connect('10.42.0.22',8087,'integration')
        # save configuration to database
        config['system'] = data
        self.saveItem(riak_frs,'apiConfig',config)
        self.logger.info("Configuration saved")
        riak_configs = self.getItems(riak_frs,'apiConfig')


    #Riak Routines
    def connect(self,host, port, bucket):
        self.logger.info("Connecting to Riak Database")
        client = riak.RiakClient(host=host, pb_port=port, protocol='pbc')
        current_bucket = client.bucket(bucket)
        self.logger.info("Connected to the bucket "+ bucket)
        return current_bucket
    def saveItem(self,client,item,items):
        newItem = client.new(item, data=items)
        newItem.store()
        return "Saved"
    def getItems(self,client,items):
        newItem = client.get(items)
        retrievedItem = newItem.data
        return retrievedItem
    def updateItems(self,client,items,itemKey,updateItem):
        newItem = client.get(items)
        newItem.data[itemKey] = updateItem
        newItem.store()
    def createApi(self,data=None,authType='Basic',task='list',request={'cluster_id':1}):
        if task == 'create':
            # Create Authentication
            if authType == 'Basic':
                authServiceName = 'zato.security.basic-auth.create'
                authRequest = { 'cluster_id':1,'name':'Basic-1','is_active':True,'realm':'Basic-1','username':'basic-1'}
                authResponse = bunch.bunchify(client.invoke(authSeviceName,authRequest))
                client.invoke('zato.security.basic-auth.change-password',authResponse.id,data.password1,data.password2)
                data['security_id'] = authResponse.id
            if authType == 'ApiKey':
                authServiceName = 'zato.security.apikey.create'
                authRequest = { 'cluster_id':1,'name':'Basic-1','is_active':True,'username':'basic-1'}
                authResponse = bunch.bunchify(client.invoke(authSeviceName,authRequest))
                client.invoke('zato.security.apikey.change-password',authResponse.id,data.password1,data.password2)
                data['security_id'] = authResponse.id

            serviceName = 'zato.http-soap.create'
            request = data
            client.invoke(seviceName,request)
        else:
            serviceName = 'zato.http-soap.get-list'
            client.invoke(seviceName,request)
