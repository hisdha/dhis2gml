# -*- coding: utf-8 -*-
# Facility Registry Service
# Creates facility registry from systems delegated as Master based on openHIE architecture
#

from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
import json,bunch,uuid
import riak,pandas as pd, jellyfish as jf

from urllib.parse import parse_qs
# Custom services
#import database
# Zato
from zato.server.service import Service

class dataStoreApi(Service):
    """ DataStore utilities.
    """
    def __init__(self):
		self.host = "localhost"
		self.port = "8087"
        self.bucket = "dataStore"

    #Riak Routines
    def connect(self,host=None, port=None, bucket=None):
        self.logger.info("Connecting to Riak Database")
        client = riak.RiakClient(host=host, pb_port=port, protocol='pbc')
        current_bucket = client.bucket(bucket)
        self.logger.info("Connected to the bucket "+ bucket)
        return current_bucket
    def saveItem(self,client,item,items):
        newItem = client.new(item, data=items)
        newItem.store()
        return "Saved"
    def getItems(self,client,items):
        newItem = client.get(items)
        retrievedItem = newItem.data
        return retrievedItem
    def updateItems(self,client,items,itemKey,updateItem):
        newItem = client.get(items)
        newItem.data[itemKey] = updateItem
        newItem.store()
