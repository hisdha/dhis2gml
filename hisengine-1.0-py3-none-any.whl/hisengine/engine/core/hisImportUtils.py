# -*- coding: utf-8 -*-
#!/usr/bin/env python
# Map gesis to DHIS2
#


from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
from json import dumps
import jellyfish as jf, flashtext as ft
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

import requests,urllib,sqlalchemy as sql
import os
import string
import random
import json
import datetime
import pandas as pd
import numpy as np
from hisengine.multiparrallel import multiprocessingApply
from py_expression_eval import Parser

import moment
from operator import itemgetter
# Zato
#from zato.server.service import Service

class hisImportUtils:
	def __init__(self):
		self.path = os.path.abspath(os.path.dirname(__file__))
		newPath = self.path.split('/')
		newPath.pop(-1)
		self.fileDirectory = '/'.join(newPath)
		self.url = ""
		self.username = ''
	# Fill with start of date of a week
	def fillStartDate(self,period=None):
		startOfMidPeriod = period.split('W')
		startEndDates = self.getStartEndDates(int(startOfMidPeriod[0]),int(startOfMidPeriod[1]))
		return moment.date(startEndDates[0]).format('YYYY-MM-DD')
	# Get start and end date
	def getStartEndDates(self,year, week):
		d = moment.date(year,1,1).date
		if(d.weekday() <= 3):
			d = d - datetime.timedelta(d.weekday())
		else:
			d = d + datetime.timedelta(7-d.weekday())
		dlt = datetime.timedelta(days = (week-1)*7)
		return [d + dlt,  d + dlt + datetime.timedelta(days=6)]
	# melt data
	def meltData(self,df=None,variables=None,values=None):
		return pd.melt(df,id_vars=variables,value_vars=values)
	# create an array based on a column
	def createArray(self,data=None,column=None):
		newData = [col[column] for col in data]
		return newData
	# get data value
	def checkOrgUnitData(self,row,orgUnitColumn,url=None,session=requests.Session(),params={}):
		params['orgUnit'] = row[orgUnitColumn]
		data= self.getDHIS2Item(url,session,'dataValueSets',params=params)
		if type(data) is dict and 'dataValues' in data.keys():
			return True
		else:
			return False
	# Tranform json object or array to flat views
	# @param valueSet - json value set
	def transformJson(self,valueSet):
		jsonValueSet = []
		for value in valueSet:
			jsonObject = {}
			for key,val in value.items():
				if type(val) is dict:
					for k,v in val.items():
						newKey = '{}_{}'.format(key,k)
						jsonObject[newKey] = v
				elif type(val) is list:
					for kv in val:
						if 'level' in list(kv.keys()):
							for k,v in kv.items():
								if k is not 'level':
									newKey = '{}_{}_{}'.format(key,kv['level'],k)
									jsonObject[newKey] = v
								else:
									pass
						else:
							for k,v in kv.items():
								newKey = '{}_{}'.format(key,k)
								jsonObject[newKey] = v

				else:
					jsonObject[key]= val
			jsonValueSet.append(jsonObject)
		return jsonValueSet
	# Create columns from split or list
	def createSplitColumns(self,data=None,split=None,columns=None,separator=None,expand=True):
		if separator is not None:
			data=data[split].str.split(separator,expand=expand)
			return data
		else:
			data=data[split].str.split(",",expand=expand)
			return data
	# Evaluate mathematical expressions
	def evalExpression(self,expression):
		parser = Parser()
		try:
			exp = parser.parse(expression)
			return exp.variables()
		except:
			#Expression not formed properly
			pass

	# Find maximum from list of objects
	def getMax(self,data=None,key=None):
		if key is None:
			return max(data)
		else:
			return max(data, key=lambda x:x[key])
	# Find minimum from list of objects
	def getMin(self,data=None,key=None):
		if key is None:
			return min(data)
		else:
			return min(data, key=lambda x:x[key])
	# Get word ratio using fuzzywuzzy
	def getRatio(self,row,column=None,searchKey=None):
		for v in searchKey.tolist():
			if fuzz.token_sort_ratio(row[column],v) == 100:
				return fuzz.token_sort_ratio(row[column],v)
		return 0
	# combine data elements to categoryOptionCombo
	def combineDataElementOptionCombo(self,row,lookupDf=None,checkColumn=None,dataElementColumn=None,optionComboColumn=None):
		dataElement = str(row[dataElementColumn])
		optionCombo = str(row[optionComboColumn])
		searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
		formulaSchema= []
		# Check if it is indicator or dataElement or optionCombo
		if dataElement is not None:
			for key in searchKey.index:
				checkValue = str(searchKey.at[key,checkColumn])
				if checkValue in dataElement:
					if optionCombo is not None:
						replaceValue = "{}.{}".format(checkValue,optionCombo)
						dataElement = dataElement.replace(checkValue,replaceValue)
						formulaSchema.append(replaceValue)
		return pd.Series((dataElement, formulaSchema ))
	# Compare values in strings
	def compareWords(self,row,column=None,lookupDf=None,checkColumn=None,fields=None):
		matches = str(row[column])
		matched = False
		indicatorSchema = None
		categoryType = "dataelement"
		if matches is not None or matches != "":
			if '#' in matches or '{' in matches or '}' in matches:
				matches = matches.replace('#','')
				matches = matches.replace('{','')
				matches = matches.replace('}','')
				searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
				#searchKey = lookupDf
				for key in searchKey.index:
					checkValue = str(searchKey.at[key,checkColumn])
					if '#' in checkValue or '{' in checkValue or '}' in checkValue:
						checkValue = checkValue.replace('#','')
						checkValue = checkValue.replace('{','')
						checkValue = checkValue.replace('}','')
						checkExp = self.evalExpression(checkValue)
						matchExp = self.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "indicator"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
					else:
						checkExp = self.evalExpression(checkValue)
						matchExp = self.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "indicator"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
			else:
				#searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
				searchKey = lookupDf
				for key in searchKey.index:
					checkValue = str(searchKey.at[key,checkColumn])
					if '#' in checkValue or '{' in checkValue or '}' in checkValue:
						checkValue = checkValue.replace('#','')
						checkValue = checkValue.replace('{','')
						checkValue = checkValue.replace('}','')
						checkExp = self.evalExpression(checkValue)
						matchExp = self.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "dataelement"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
					else:
						checkExp = self.evalExpression(checkValue)
						matchExp = self.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "dataelement"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)

		return pd.Series(indicatorSchema)
	# Replace values in strings
	def replaceWords(self,row,column=None,lookupDf=None,checkColumn=None,replaceColumn=None,separator=None):
		matches = str(row[column])
		if ',' in matches:
			matches = matches.replace(',','+')
		searchKey = lookupDf.drop_duplicates(subset=replaceColumn, keep="first")
		dataElementSchema = []
		for key in searchKey.index:
			checkValue = str(searchKey.at[key,checkColumn])
			replaceValue = str(searchKey.at[key,replaceColumn])
			if checkValue in matches:
				matches = matches.replace(checkValue,replaceValue)
				dataElementSchema.append(replaceValue)
			elif checkValue.upper() in matches:
				matches = matches.replace(checkValue.upper(),replaceValue)
				dataElementSchema.append(replaceValue)
			else:
				pass
		return pd.Series((matches,dataElementSchema))
	# Search for keywords
	def searchKeyWords(self,row,column=None,lookupDf=None,checkColumn=None,fields=None,separator=None,type=None):
		matches = []
		fieldsSchema = []
		searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
		for key in searchKey.index:
			jlookupValue = searchKey.at[key,checkColumn]
			lookupValue=','.join([s.strip() for s in jlookupValue.split(',')])
			sortedLookupValue =[s.strip() for s in sorted(jlookupValue.split(','))]
			jsortedLookupValue =','.join(sortedLookupValue)
			searchWord = row[column]
			if '40-44' in str(searchWord):
				searchWord=searchWord.replace('40-44','40-45')
			jsearchWord =[s.strip() for s in searchWord.split(',')]
			ratio = fuzz.token_sort_ratio(jsearchWord,lookupValue)
			if (str(lookupValue) in str(jsearchWord)) or (str(jsortedLookupValue) in str(jsearchWord)):
				lookupIndex =jsearchWord.index(lookupValue) if lookupValue in jsearchWord else None
				matches.append({'ratio':ratio,'lookupValue':lookupValue,'lookupValueWidth':len(sortedLookupValue),'index':lookupIndex})
				if fields is not None:
					fieldsSchema = [str(searchKey.at[key,field]) for field in fields]
		if len(matches) > 0:
			newMatch = []
			for smatch in matches:
				if smatch['index'] is not None:
					newMatch.insert(smatch['index'],str(smatch['lookupValue']))
			fieldsSchema.append(','.join(newMatch))
			fieldsSchema.append(newMatch)
			fieldsSchema.append(matches)
			fieldsSchema = tuple(fieldsSchema)
			return pd.Series(fieldsSchema)
		else:
			return ""

	# swap and test text
	def swapText(self,text=None):
		if text is not None:
			if ',' in text:
				return ','.join(sorted([s.strip() for s in text.split(',')]))
			else:
				return text
		else:
			return text
	# clean text
	def cleanText(self,text=None,swapText=True,separator=None,oldSeparator=',',prefix="",replace=None):
		if separator is not None:
			cleanedText = '{}{}'.format(prefix,separator.join([s.strip() for s in text.split(oldSeparator)]))
			if replace is not None:
				for rep in replace:
					for key in rep:
						cleanedText=cleanedText.replace(key,rep[key])
			if swapText is False:
				return pd.Series(cleanedText)
			if swapText:
				return pd.Series(self.swapText(text=cleanedText))
		else:
			cleanedText = '{}{}'.format(prefix,','.join([s.strip() for s in text.split(oldSeparator)]))
			if replace is not None:
				for rep in replace:
					for key in rep:
						cleanedText=cleanedText.replace(key,rep[key])
			if swapText is False:
				return pd.Series(cleanedText)
			if swapText:
				return pd.Series(self.swapText(text=cleanedText))
	# Add extra columns to DHIS2 data Elements
	def appendMatchedColumns(self,srcMap=None,destMap=None,left=None,right=None,check=None,match=None,dataElement=None,optionCombo=None,columnName=None,fields=None):
		if match is 'search':
			srcMap[columnName] = multiprocessingApply(srcMap,self.searchKeyWords,args=(left,destMap,right,fields),axis=1,workers=10)
		elif match is 'replace':
			srcMap[columnName] =multiprocessingApply(srcMap,self.replaceWords,args=('safe_indicator',destMap,'dataElement_code','dataElement_id'),axis=1,workers=10)
		elif match is 'compare':
			srcMap[columnName] =multiprocessingApply(srcMap,self.compareWords,args=(check,destMap,dataElement,fields),axis=1,workers=10)
		elif match is 'clean':
			srcMap[columnName] =multiprocessingApply(srcMap,self.cleanText,args=(check,destMap,dataElement,fields),axis=1,workers=10)
		else:
			srcMap[columnName] =multiprocessingApply(srcMap,self.combineDataElementOptionCombo,args=(destMap,dataElement,optionCombo,check),axis=1,workers=10)
		return srcMap
	# Get HTTP session
	def getLoginSession(self,username,password,sid=None):
		session = requests.Session()
		session.auth = (username,password)
		session.headers.update({'X-IEngine': sid})
		return session
	# Get Authentication details e.g .his_config.json
	def getAuth(self,secrets=None,path=None):
		if path is None:
			path = self.fileDirectory
		if secrets is None:
			secrets = '.his_config.json'
		with open(os.path.join(path,secrets),'r') as jsonfile:
			auth = json.load(jsonfile)
			auth = bunch.Bunch(auth)
			print("Authentication credentials loaded successfully")
			return auth
	def getDHIS2ItemById(self,url,session,item,id):
	    items = []
	    try:
	        get_request = session.get(url + "/api/" + item + "/" + id + ".json",params={"paging":"false"})
	        print(str(get_request.status_code))
	        items = get_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Get DHIS2 Item
	def getDHIS2Item(self,url,session,item,params=None):
	    items = []
	    if params is None:
	    	params = {}

	    try:
	        get_request = session.get(url + "/api/" + item + ".json",params=params)
	        print("HTTP request ({}) returned: {} ".format(item,str(get_request.status_code)))
	        items = get_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Post DHIS2 item
	def postDHIS2Item(self,url,session,item,data=None):
	    items = []
	    try:
	        post_request = session.post(url + "/api/" + item,json=data)
	        print("HTTP request ({}) returned: {} ".format(item,str(post_request.text)))
	        items = post_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Update DHIS2 item
	def updateDHIS2Item(self,url,session,item,data):
	    items = []
	    try:
	        put_request = session.put(url + "/api/" + item,json=data)
	        print("HTTP request ({}) returned: {} ".format(item,str(put_request.text)))
	        items = put_request.json()
	        return items
	    except requests.exceptions.RequestException as e:
	        print(e)
	    return items

	def getDBConnection(self,driver=None,path="c:\\",db=None,dbExt=".mdb",dsn=None):
		engine = None
		connectionString = (
			r'DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};'
			r'DBQ='{}.}.{}.{}.format(path,db,dbExt)';'
			r'ExtendedAnsiSQL=1;'
		)
		print("Connection String::",connectionString)
		if driver == 'MSACCESS':
			params = urllib.parse.quote_plus("DRIVER={Microsoft Access Driver (*.mdb,*.accdb)};DBQ='{}.{}.{}.format(path,db,dbExt)';ExtendedAnsiSQL=1;")
			connectionUri = f"access+pyodbc:///?odbc_connect={params}"
			engine = sql.create_engine(connectionUri)
		elif driver == 'MSSQL':
			params = urllib.parse.quote_plus("DRIVER={SQL Server Native Client 10.0};SERVER=dagger;DATABASE=" +db+";UID=user;PWD=password")
			engine = sql.create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
		else:
			pass
		return engine

	# Read in Panda file
	def getPdFile(self,fileName=None,type=None,folder=None,values=None,addFileExt=True,indexCol=False,replaceNull=False,delimiter=',',encoding='ISO-8859-1',path=None):
		df = pd.DataFrame()
		if type == 'csv':
			if addFileExt:
				if path is None:
					path = self.fileDirectory
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(path,folder,fileName),'csv'),encoding='ISO-8859-1',index_col=indexCol,sep=delimiter)
				if replaceNull:
					df = mixedDf
				else:
					df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
			else:
				if path is None:
					path = self.fileDirectory
				mixedDf = pd.read_csv(os.path.join(path,folder,fileName),encoding='ISO-8859-1',sep=delimiter)
				if replaceNull:
					df = mixedDf
				else:
					df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
		elif type == 'json':
			if values is not None:
				#df= pd.DataFrame.from_records(values)
				df=pd.io.json.json_normalize(values)
			else:
				df= pd.read_json(fileName)
		elif type== 'sql':
			if path is None:
				path = self.fileDirectory
			engine = self.getDBConnection('MSACCESS','')
			df = pd.read_sql('tRM_CSB_Maternite',engine)
			df.to_csv(os.path.join(path,folder,'mdg.csv'), sep=',', encoding='utf-8')
		else:
			pass
		df.dropna(axis=0,how="all")
		df.dropna(axis=1,how="all")
		return df

    # create Panda Data Frame from event data
	def createDataFrame(self,events,type):
		cols = self.createColumns(events['headers'],type)
		dataFrame = pd.DataFrame.from_records(events['rows'],columns=cols)
		return dataFrame
	# Get Uids from mappings
	def getUid(self,column,id):
		return id
	# Join strings
	def strJoin(self,*args):
		return ''.join(map(str, args))
	#create DHIS2 periods
	def createPeriods(self,**args):
		p = pd.to_datetime("{}-{}".format(args["year"],args["month"]))
		period = self.strJoin(f"{p:%Y}",f"{p:%m}")
		return period

	# create dataValueSet from gesis to DHIS2
	def createDataValueSet(self,df,year=None,month=None,idVars=None,valueVars=None):
		if idVars is not None and valueVars is not None:
			df['period'] = df.apply(lambda row: self.createPeriods(year=row[year],month=row[month]),axis=1)
			new_df = pd.melt(df,id_vars=idVars,value_vars=df.columns.drop(valueVars).tolist(),var_name='fieldname')
			return new_df
		else:
			print("No melt columns were provided")
			return

	# create Output files
	def createResultFile(self,values,folder,filename,type=None,chunksize=None,addFileExt=True,sheetName="Sheet1",path=None):
		values.drop(values.columns[values.columns.str.contains('unnamed',case=False)],axis=1,inplace=True)
		if path is None:
			path = self.fileDirectory
		if type=='csv':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				values.to_csv(os.path.join(path,folder,filename), sep=',', encoding='utf-8',chunksize=chunksize,index=False)
			else:
				values.to_csv(os.path.join(path,folder,filename), sep=',', encoding='utf-8',chunksize=chunksize,index=False)
		elif type=='xlsx':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				with pd.ExcelWriter(os.path.join(path,folder,filename)) as writer:
					values.to_excel(writer,sheet_name=sheetName)
			else:
				with pd.ExcelWriter(os.path.join(path,folder,filename)) as writer:
					values.to_excel(writer,sheet_name=sheetName)
		elif type=='tsv':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				values.to_csv(os.path.join(path,folder,filename), sep='\t', encoding='utf-8',chunksize=chunksize,index=False)
			else:
				values.to_csv(os.path.join(path,folder,filename), sep='\t', encoding='utf-8',chunksize=chunksize,index=False)

		else:
			filename = "{}.{}".format(filename,type)
			values.to_json(os.path.join(path,folder,filename),orient='records')
		return 'SUCCESS'

	# Split csv files
	def splitFile(self,fileName=None,type='csv',folder=None,values=None,chunksize=100000,chunkType='size',columns=None,dropColumns=None):
		dfFiles = []
		print("Platform: ",os.uname())
		if type == 'csv':
			if chunkType == 'files':
				# Read files name
				fileLocation= os.listdir(os.path.join(self.fileDirectory,folder))
				for entry in fileLocation:
					if fileName in entry:
						dfFiles.append(entry)
			elif chunkType == 'column' and columns is not None:
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(self.fileDirectory,folder,fileName),'csv'),encoding='ISO-8859-1')
				uniqueColumnData = mixedDf[columns].unique().tolist()
				#df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
				for columnValue in uniqueColumnData:
					print("File chunk by column value: ",columnValue)
					filename = '{}_{}'.format(fileName,columnValue)
					dfFiles.append(filename)
					filename = '{}.{}'.format(filename,type)
					queryColumn = "{}{}{}{}{}".format(columns,'==','"',columnValue,'"')
					chunkQuery = mixedDf.query(queryColumn)
					if dropColumns is not None:
						chunk = chunkQuery.drop(columns=dropColumns)
						chunk.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',', encoding='ISO-8859-1',index=False)
					else:
						chunkQuery.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',',encoding='ISO-8859-1',index=False)
			else:
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(self.fileDirectory,folder,fileName),'csv'),encoding='ISO-8859-1',iterator=True, chunksize=chunksize)
				#df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
				for i, chunk in enumerate(mixedDf):
					print("File chunk ",i)
					filename = '{}_{}_{}.{}'.format(fileName,'chunk',i,type)
					dfFiles.append(filename)
					chunk.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',', encoding='utf-8',index=False)
		else:
			pass
		return dfFiles

	def compareColumns(self,expression=None):
		return df.query(expression)

	# Check duplicates
	# keep { first, last, False }
	def markDuplicate(self,source=None,columns=None,label="Duplicated",keep=False):
		if source is not None and columns is not None:
			source[label] = source.duplicated(subset=columns,keep=keep)
			return source
		else:
			print("Specify source and columns")
			return source
	# Get DHIS2 OrgUnits
	def getDHIS2OrgUnits(self,url,session,params=None):
		orgUnits = self.getDHIS2Item(url,session,'organisationUnits',params=params)
		return orgUnits['organisationUnits']
	# Create element Mapping
	"""
	categoryType can be one of the { disaggregation,indicator,dataelement}
	"""
	def createMapping(self,sourceMap=None,destinationMap=None,leftColumns=None,rightColumns=None,mappings=None,category=None,resourceType=None,authority=None,map=True,categoryType=None,platform=None):
		if mappings is not None:
			for key in mappings:
				sourceMap[key['new']] = sourceMap[key['old']]

		if category is not None:
			sourceMap['category'] = category
		if categoryType is not None:
			sourceMap['categoryType'] = categoryType
		if resourceType is not None:
			sourceMap['resourceType'] = resourceType
		if authority is not None:
			systems = [{"type":"authority","value":authority },{"type":"platform","value":platform}]
			sourceMap = sourceMap.assign(system=[ systems for i in sourceMap.index])
		if map:
			df = pd.merge(sourceMap,destinationMap,how='left',left_on=leftColumns,right_on=rightColumns)
			sourceMap = df.fillna('')
		sourceMap = sourceMap.fillna('')
		return sourceMap

	# Analyse duplicates based on input csv file or same system
	def analyzeDuplicates(self,source=None,validate=None,type=None,leftColumns=None,rightColumns=None,duplicated=None,dupColumns=None,expression=None):
		merged = None
		if type.lower() ==  "csv":
			if duplicated == 'keep':
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
			elif duplicated == 'remove':
				merged_with_duplicates = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged = merged_with_duplicates.drop_duplicates(subset=dupColumns)
			else:
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
		elif type.lower() == 'system':
			merged = validate.query(expression)
			merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
		return merged

	# Join dataValues
	def combineDataValues(self,df,data=None,leftColumns=None,rightColumns=None):
		dataValues = pd.merge(df,data,how='left',left_on=leftColumns,right_on=rightColumns)

		return dataValues
	# Rename columns in a dataframe
	def renameColumns(self,data=None,columns=None):
		dataValues = data.rename(columns=columns)
		return dataValues

	# Create Import file for DHIS2
	def createDHIS2AggregateDataImport(self,data=None,columns=None):
		if (data is not None) and (columns is not None):
			return data[columns]
		else:
			print("Please specify either columns or data")
			return

	# get option __name__
	def getOptionName(self,options=None,option=None):
		if options is not None and option is not None:
			for elem in options:
				if elem.get('id') is not None:
					if option in elem['id']:
						return elem['name']
				else:
					if option in elem:
						return option
		else:
			pass
	#Create dynamic indicator totals per row per aggregation
	def createDHIS2Indicators(self,values=None,testField=None,indicatorTypeId=None,field=None,searchText=None,replacementText=None,multiple=False,replace=False,elements=None,options=None,uids=None,axis=0,prefix=None):
		if replace is False:
			if axis == 0 or axis is None:
				if (elements is not None) and (uids is not None):
					values = []
					for idx,element in enumerate(elements):
						value = {
							"decimals":0,
							"denominator": "1",
							"indicatorType": {
								"id": "T5Uu2CxWAcf"
							}
						}
						if indicatorTypeId is not None:
							value["indicatorType"] = { "id": indicatorTypeId};
						value["id"] = uids[idx]
						value["name"] = "{} {}".format(element["name"],searchText)
						value["numeratorDescription"]= "{} {} {}".format(element["name"],'Numerator',searchText)
						value["denominatorDescription"]= "{} {} {}".format(element["name"],'Denominator',searchText)
						if options is not None:
							numerator = ""
							for oidx,option in enumerate(options):
								expression = "#{"+element["id"] +"."+option+"}"
								if oidx == 0:
									numerator= expression
								else:
									numerator = "{}+{}".format(numerator,expression)
							value["numerator"]= numerator
						else:
							value["numerator"] = 0
						value["shortName"] = "{} {}".format(element["shortName"],searchText)
						values.append(value)
						#uids.pop(idx)
					return values
				else:
					print("Elements to create indicators or uids to identify indicators are missing")
					return
			elif axis == 1:
				if (options is not None) and (uids is not None):
					values = []
					for idx,option in enumerate(options):
						value = {
							"decimals":0,
							"denominator": "1",
							"indicatorType": {
								"id": "T5Uu2CxWAcf"
							}
						}
						if indicatorTypeId is not None:
							value["indicatorType"]= { "id": indicatorTypeId};
						value["id"] = uids[idx]
						catOptions= elements[0]['categoryCombo']['categoryOptionCombos'];
						if prefix is not None:
							value["name"] = "{} {} {}".format(prefix,self.getOptionName(options=catOptions,option=option),searchText)
							value["shortName"] = "{} {} {}".format(prefix,self.getOptionName(options=catOptions,option=option),searchText)
						else:
							value["name"] = "{} {}".format(self.getOptionName(options=catOptions,option=option),searchText)
							value["shortName"] = "{} {}".format(self.getOptionName(options=catOptions,option=option),searchText)
						value["numeratorDescription"]= "{} {} {}".format(self.getOptionName(options=catOptions,option=option),'Numerator',searchText)
						value["denominatorDescription"]= "{} {} {}".format(self.getOptionName(options=catOptions,option=option),'Denominator',searchText)
						if elements is not None:
							numerator = ""
							for oidx,element in enumerate(elements):
								expression = "#{"+element["id"] +"."+option+"}"
								if oidx == 0:
									numerator= expression
								else:
									numerator = "{}+{}".format(numerator,expression)
							value["numerator"]= numerator
						else:
							value["numerator"] = 0

						values.append(value)
						#uids.pop(idx)
					return values
				else:
					print("Elements to create indicators or uids to identify indicators are missing")
					return
			else:
				print("This axis is not supported")
				return

		else:
			if (replacementText is not None) and (searchText is not None) and (values is not None) and (field is not None) and (testField is not None):
				for value in values:
					if value[testField].find(searchText) > -1 and value[field].find(replacementText) == -1:
						currentValueArray = value[field].split('+')
						if multiple is False:
							test1 = (currentValueArray[0].replace('#{','')).split('.')
							test2 = (currentValueArray[1].replace('#{','')).split('.')
							if test1[0] == test2[0]:
								de = "#{" + test1[0]
								replacement = replacementText +"}"
								value[field]= "{}+{}.{}".format(value[field],de,replacement)
							else:
								value[field]= "{}".format(value[field])
						else:
							print("This is not yet supported")
							return
							#value[field]= "{}+{}".format(value[field],replacementText)
					else:
						pass

				return values
			else:
				print("Required parameters missing")
				return
