import riak

class Database:
    def __init__(self):
        print("Initiating")
    def connect(self, port, bucket):
        print("Connecting to Riak Database")
        client = riak.RiakClient(port=port, transport_class=riak.RiakPbcTransport)
        test_bucket = client.bucket(bucket)        
    
    def sendToRabbitMQ(self,message,sender,reciever):
        print("Sending messages to RabbitMQ")
    
    def recieveFromRabbitMQ(self,message,sender,reciever):
        print("Recieving messages from RabiitMQ")
    
