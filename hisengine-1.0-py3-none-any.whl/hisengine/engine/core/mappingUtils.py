# -*- coding: utf-8 -*-
#!/usr/bin/env python
# Create Mapping for DHIS2 to DHIS2 or any other systems
#


from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
from json import dumps
import os
import string
import random
import json
import datetime
import pandas as pd
import numpy as np
from hisengine.engine.core.multiparrallel import multiprocessingApply
from py_expression_eval import Parser
from hisengine.engine.core.hisApi import hisApi
from hisengine.engine.core.hisUtils import hisUtils

import moment
from operator import itemgetter
# Zato
#from zato.server.service import Service
hu = hisUtils()

class mappingUtils:
	def __init__(self):
		self.path = os.path.abspath(os.path.dirname(__file__))
		newPath = self.path.split('/')
		newPath.pop(-1)
		self.fileDirectory = '/'.join(newPath)
    
	# combine data elements to categoryOptionCombo
	def combineDataElementOptionCombo(self,row,lookupDf=None,checkColumn=None,dataElementColumn=None,optionComboColumn=None):
		dataElement = str(row[dataElementColumn])
		optionCombo = str(row[optionComboColumn])
		searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
		formulaSchema= []
		# Check if it is indicator or dataElement or optionCombo
		if dataElement is not None:
			for key in searchKey.index:
				checkValue = str(searchKey.at[key,checkColumn])
				if checkValue in dataElement:
					if optionCombo is not None:
						replaceValue = "{}.{}".format(checkValue,optionCombo)
						dataElement = dataElement.replace(checkValue,replaceValue)
						formulaSchema.append(replaceValue)
		return pd.Series((dataElement, formulaSchema ))
	# Compare values in strings
	def compareWords(self,row,column=None,lookupDf=None,checkColumn=None,fields=None):
		matches = str(row[column])
		matched = False
		indicatorSchema = None
		categoryType = "dataelement"
		if matches is not None or matches != "":
			if '#' in matches or '{' in matches or '}' in matches:
				matches = matches.replace('#','')
				matches = matches.replace('{','')
				matches = matches.replace('}','')
				searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
				#searchKey = lookupDf
				for key in searchKey.index:
					checkValue = str(searchKey.at[key,checkColumn])
					if '#' in checkValue or '{' in checkValue or '}' in checkValue:
						checkValue = checkValue.replace('#','')
						checkValue = checkValue.replace('{','')
						checkValue = checkValue.replace('}','')
						checkExp = hu.evalExpression(checkValue)
						matchExp = hu.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "indicator"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
					else:
						checkExp = hu.evalExpression(checkValue)
						matchExp = hu.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "indicator"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
			else:
				#searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
				searchKey = lookupDf
				for key in searchKey.index:
					checkValue = str(searchKey.at[key,checkColumn])
					if '#' in checkValue or '{' in checkValue or '}' in checkValue:
						checkValue = checkValue.replace('#','')
						checkValue = checkValue.replace('{','')
						checkValue = checkValue.replace('}','')
						checkExp = hu.evalExpression(checkValue)
						matchExp = hu.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "dataelement"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)
					else:
						checkExp = hu.evalExpression(checkValue)
						matchExp = hu.evalExpression(matches)
						if checkExp == matchExp and checkExp is not None:
							matched = True
							categoryType = "dataelement"
							if fields is not None:
								indicatorSchema=[str(searchKey.at[key,field]) for field in fields]
								indicatorSchema.append(checkValue)
								indicatorSchema.append(matched)
								indicatorSchema.append(categoryType)
								indicatorSchema = tuple(indicatorSchema)

		return pd.Series(indicatorSchema)
	# Replace values in strings
	def replaceWords(self,row,column=None,lookupDf=None,checkColumn=None,replaceColumn=None,separator=None):
		matches = str(row[column])
		if ',' in matches:
			matches = matches.replace(',','+')
		searchKey = lookupDf.drop_duplicates(subset=replaceColumn, keep="first")
		dataElementSchema = []
		for key in searchKey.index:
			checkValue = str(searchKey.at[key,checkColumn])
			replaceValue = str(searchKey.at[key,replaceColumn])
			if hu.isStringInText(phrase=checkValue, text=matches):
				matches = matches.replace(checkValue,replaceValue)
				dataElementSchema.append(replaceValue)
			elif hu.isStringInText(phrase=checkValue.upper(), text=matches):
				matches = matches.replace(checkValue.upper(),replaceValue)
				dataElementSchema.append(replaceValue)
			else:
				pass
		return pd.Series((matches,dataElementSchema))
	# Search for keywords
	def searchKeyWords(self,row,column=None,lookupDf=None,checkColumn=None,fields=None,separator=None,type=None):
		matches = []
		fieldsSchema = []
		searchKey = lookupDf.drop_duplicates(subset=checkColumn, keep="first")
		for key in searchKey.index:
			jlookupValue = searchKey.at[key,checkColumn]
			lookupValue=','.join([s.strip() for s in jlookupValue.split(',')])
			sortedLookupValue =[s.strip() for s in sorted(jlookupValue.split(','))]
			jsortedLookupValue =','.join(sortedLookupValue)
			searchWord = row[column]
			jsearchWord =[s.strip() for s in searchWord.split(',')]
			if hu.isFullStringInText(str(lookupValue),str(searchWord)) or hu.isFullStringInText(str(jsortedLookupValue), str(searchWord)):
				
				lookupIndex =jsearchWord.index(lookupValue) if hu.isFullStringInText(lookupValue, jsearchWord) else None
				matches.append({'lookupValue':lookupValue,'lookupValueWidth':len(sortedLookupValue),'index':lookupIndex})
				if fields is not None:
					fieldsSchema = [str(searchKey.at[key,field]) for field in fields]
		if len(matches) > 0:
			newMatch = []
			for smatch in matches:
				if smatch['index'] is not None:
					newMatch.insert(smatch['index'],str(smatch['lookupValue']))
			fieldsSchema.append(','.join(newMatch))
			fieldsSchema.append(newMatch)
			fieldsSchema.append(matches)
			fieldsSchema = tuple(fieldsSchema)
			return pd.Series(fieldsSchema)
		else:
			return ""

	# swap and test text
	def swapText(self,text=None):
		if text is not None:
			if ',' in text:
				return ','.join(sorted([s.strip() for s in text.split(',')]))
			else:
				return text
		else:
			return text
	# clean text
	def cleanText(self,text=None,swapText=True,separator=None,oldSeparator=',',prefix="",replace=None):
		if separator is not None:
			cleanedText = '{}{}'.format(prefix,separator.join([s.strip() for s in text.split(oldSeparator)]))
			if replace is not None:
				for rep in replace:
					for key in rep:
						cleanedText=cleanedText.replace(key,rep[key])
			if swapText is False:
				return pd.Series(cleanedText)
			if swapText:
				return pd.Series(self.swapText(text=cleanedText))
		else:
			cleanedText = '{}{}'.format(prefix,','.join([s.strip() for s in text.split(oldSeparator)]))
			if replace is not None:
				for rep in replace:
					for key in rep:
						cleanedText=cleanedText.replace(key,rep[key])
			if swapText is False:
				return pd.Series(cleanedText)
			if swapText:
				return pd.Series(self.swapText(text=cleanedText))
	# Add extra columns to DHIS2 data Elements
	def appendMatchedColumns(self,srcMap=None,destMap=None,left=None,right=None,check=None,match=None,dataElement=None,optionCombo=None,columnName=None,fields=None):
		if match == 'search':
			srcMap[columnName] = multiprocessingApply(srcMap,self.searchKeyWords,args=(left,destMap,right,fields),axis=1,workers=10)
		elif match == 'replace':
			srcMap[columnName] =multiprocessingApply(srcMap,self.replaceWords,args=(left,destMap,check,dataElement),axis=1,workers=10)
		elif match == 'compare':
			srcMap[columnName] =multiprocessingApply(srcMap,self.compareWords,args=(check,destMap,dataElement,fields),axis=1,workers=10)
		elif match == 'clean':
			srcMap[columnName] =multiprocessingApply(srcMap,self.cleanText,args=(check,destMap,dataElement,fields),axis=1,workers=10)
		else:
			srcMap[columnName] =multiprocessingApply(srcMap,self.combineDataElementOptionCombo,args=(destMap,dataElement,optionCombo,check),axis=1,workers=10)
		return srcMap


	def compareColumns(self,expression=None):
		return df.query(expression)
	# Create element Mapping
	"""
	categoryType can be one of the { disaggregation,indicator,dataelement}
	"""
	def createMapping(self,sourceMap=None,destinationMap=None,leftColumns=None,rightColumns=None,mappings=None,category=None,resourceType=None,authority=None,map=True,categoryType=None,platform=None):
		if mappings is not None:
			for key in mappings:
				sourceMap[key['new']] = sourceMap[key['old']]

		if category is not None:
			sourceMap['category'] = category
		if categoryType is not None:
			sourceMap['categoryType'] = categoryType
		if resourceType is not None:
			sourceMap['resourceType'] = resourceType
		if authority is not None:
			systems = [{"type":"authority","value":authority },{"type":"platform","value":platform}]
			sourceMap = sourceMap.assign(system=[ systems for i in sourceMap.index])
		if map:
			df = pd.merge(sourceMap,destinationMap,how='left',left_on=leftColumns,right_on=rightColumns)
			sourceMap = df.fillna('')
		sourceMap = sourceMap.fillna('')
		return sourceMap

	# Analyse duplicates based on input csv file or same system
	def analyzeDuplicates(self,source=None,validate=None,type=None,leftColumns=None,rightColumns=None,duplicated=None,dupColumns=None,expression=None):
		merged = None
		if type.lower() ==  "csv":
			if duplicated == 'keep':
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
			elif duplicated == 'remove':
				merged_with_duplicates = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged = merged_with_duplicates.drop_duplicates(subset=dupColumns)
			else:
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
		elif type.lower() == 'system':
			merged = validate.query(expression)
			merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
		return merged

		return dataValues
	

	# get option __name__
	def getOptionName(self,options=None,option=None):
		if options is not None and option is not None:
			for elem in options:
				if elem.get('id') is not None:
					if option in elem['id']:
						return elem['name']
				else:
					if option in elem:
						return option
		else:
			pass
	#Create dynamic indicator totals per row per aggregation
	def createDHIS2Indicators(self,values=None,testField=None,indicatorTypeId=None,field=None,searchText=None,replacementText=None,multiple=False,replace=False,elements=None,options=None,uids=None,axis=0,prefix=None):
		if replace is False:
			if axis == 0 or axis is None:
				if (elements is not None) and (uids is not None):
					values = []
					for idx,element in enumerate(elements):
						value = {
							"decimals":0,
							"denominator": "1",
							"indicatorType": {
								"id": "T5Uu2CxWAcf"
							}
						}
						if indicatorTypeId is not None:
							value["indicatorType"] = { "id": indicatorTypeId};
						value["id"] = uids[idx]
						value["name"] = "{} {}".format(element["name"],searchText)
						value["numeratorDescription"]= "{} {} {}".format(element["name"],'Numerator',searchText)
						value["denominatorDescription"]= "{} {} {}".format(element["name"],'Denominator',searchText)
						if options is not None:
							numerator = ""
							for oidx,option in enumerate(options):
								expression = "#{"+element["id"] +"."+option+"}"
								if oidx == 0:
									numerator= expression
								else:
									numerator = "{}+{}".format(numerator,expression)
							value["numerator"]= numerator
						else:
							value["numerator"] = 0
						value["shortName"] = "{} {}".format(element["shortName"],searchText)
						values.append(value)
						#uids.pop(idx)
					return values
				else:
					print("Elements to create indicators or uids to identify indicators are missing")
					return
			elif axis == 1:
				if (options is not None) and (uids is not None):
					values = []
					for idx,option in enumerate(options):
						value = {
							"decimals":0,
							"denominator": "1",
							"indicatorType": {
								"id": "T5Uu2CxWAcf"
							}
						}
						if indicatorTypeId is not None:
							value["indicatorType"]= { "id": indicatorTypeId};
						value["id"] = uids[idx]
						catOptions= elements[0]['categoryCombo']['categoryOptionCombos'];
						if prefix is not None:
							value["name"] = "{} {} {}".format(prefix,self.getOptionName(options=catOptions,option=option),searchText)
							value["shortName"] = "{} {} {}".format(prefix,self.getOptionName(options=catOptions,option=option),searchText)
						else:
							value["name"] = "{} {}".format(self.getOptionName(options=catOptions,option=option),searchText)
							value["shortName"] = "{} {}".format(self.getOptionName(options=catOptions,option=option),searchText)
						value["numeratorDescription"]= "{} {} {}".format(self.getOptionName(options=catOptions,option=option),'Numerator',searchText)
						value["denominatorDescription"]= "{} {} {}".format(self.getOptionName(options=catOptions,option=option),'Denominator',searchText)
						if elements is not None:
							numerator = ""
							for oidx,element in enumerate(elements):
								expression = "#{"+element["id"] +"."+option+"}"
								if oidx == 0:
									numerator= expression
								else:
									numerator = "{}+{}".format(numerator,expression)
							value["numerator"]= numerator
						else:
							value["numerator"] = 0

						values.append(value)
						#uids.pop(idx)
					return values
				else:
					print("Elements to create indicators or uids to identify indicators are missing")
					return
			else:
				print("This axis is not supported")
				return

		else:
			if (replacementText is not None) and (searchText is not None) and (values is not None) and (field is not None) and (testField is not None):
				for value in values:
					if value[testField].find(searchText) > -1 and value[field].find(replacementText) == -1:
						currentValueArray = value[field].split('+')
						if multiple is False:
							test1 = (currentValueArray[0].replace('#{','')).split('.')
							test2 = (currentValueArray[1].replace('#{','')).split('.')
							if test1[0] == test2[0]:
								de = "#{" + test1[0]
								replacement = replacementText +"}"
								value[field]= "{}+{}.{}".format(value[field],de,replacement)
							else:
								value[field]= "{}".format(value[field])
						else:
							print("This is not yet supported")
							return
							#value[field]= "{}+{}".format(value[field],replacementText)
					else:
						pass

				return values
			else:
				print("Required parameters missing")
				return
