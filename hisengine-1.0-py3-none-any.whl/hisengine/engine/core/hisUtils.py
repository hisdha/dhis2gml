# -*- coding: utf-8 -*-
#!/usr/bin/env python
# HIS Utilities
#


from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
from json import dumps
import os
import string
import random
import json
import datetime
import pandas as pd
import numpy as np
from hisengine.engine.core.multiparrallel import multiprocessingApply
from py_expression_eval import Parser
from hisengine.engine.core.hisApi import hisApi
import re
import fnmatch
import requests,urllib,sqlalchemy as sql,pyodbc
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.automap import automap_base
import moment
from operator import itemgetter
from sqlalchemy import MetaData, Table
from sqlalchemy.ext.declarative import declarative_base
# Zato
#from zato.server.service import Service

class hisUtils:
	def __init__(self):
		self.path = os.path.abspath(os.path.dirname(__file__))
		newPath = self.path.split('/')
		newPath.pop(-1)
		self.fileDirectory = '/'.join(newPath)
	# Fill with start of date of a week
	def fillStartDate(self,period=None):
		startOfMidPeriod = period.split('W')
		startEndDates = self.getStartEndDates(int(startOfMidPeriod[0]),int(startOfMidPeriod[1]))
		return moment.date(startEndDates[0]).format('YYYY-MM-DD')
	# Get start and end date
	def getStartEndDates(self,year, week):
		d = moment.date(year,1,1).date
		if(d.weekday() <= 3):
			d = d - datetime.timedelta(d.weekday())
		else:
			d = d + datetime.timedelta(7-d.weekday())
		dlt = datetime.timedelta(days = (week-1)*7)
		return [d + dlt,  d + dlt + datetime.timedelta(days=6)]
	# melt data
	def meltData(self,df=None,variables=None,values=None):
		return pd.melt(df,id_vars=variables,value_vars=values)
	# create an array based on a column
	def createArray(self,data=None,column=None):
		newData = [col[column] for col in data]
		return newData
	# Transform data
	def flattenJsonData(self,data,sep="_"):
		return pd.json_normalize(data=data,meta_prefix="meta",sep=sep)

	# Create columns from split or list
	def createSplitColumns(self,data=None,split=None,columns=None,separator=None,expand=True):
		if separator is not None:
			data=data[split].str.split(separator,expand=expand)
			return data
		else:
			data=data[split].str.split(",",expand=expand)
			return data

	# Concetenate columns
	def joinColumns(self,data=None,column="joined",columns=None,separator=',',expand=True,default=None):
		data[column]=data[columns[0]].str.strip().str.cat(data[columns[1]].str.strip(),sep=separator)		
		if default is None:
			data[column]=data[column].str.replace("(^,)|(,$)","")
		else:
			data[column]=data[column].str.replace("NA",default).str.replace("(^,$)",default).str.replace("(^,)|(,$)","")
		return data
	# Evaluate mathematical expressions
	def evalExpression(self,expression):
		parser = Parser()
		try:
			exp = parser.parse(expression)
			return exp.variables()
		except:
			#Expression not formed properly
			pass

	# Find maximum from list of objects
	def getMax(self,data=None,key=None):
		if key is None:
			return max(data)
		else:
			return max(data, key=lambda x:x[key])
	# Find minimum from list of objects
	def getMin(self,data=None,key=None):
		if key is None:
			return min(data)
		else:
			return min(data, key=lambda x:x[key])
	# Get word ratio using fuzzywuzzy
	def getRatio(self,row,column=None,searchKey=None):
		for v in searchKey.tolist():
			if fuzz.token_sort_ratio(row[column],v) == 100:
				return fuzz.token_sort_ratio(row[column],v)
		return 0
	# Get File Names from folder
	def getFileNames(self,path=None,folder="",fileName=""):
		dfFiles = []
		if path is None:
			fileLocation= os.listdir(os.path.join(self.fileDirectory,folder))
			for entry in fileLocation:
				if fileName in entry:
					dfFiles.append(entry)

		else:
			# Read files name
			fileLocation= os.listdir(os.path.join(path,folder))
			for entry in fileLocation:
				if fileName in entry:
					dfFiles.append(entry)	
		return dfFiles



	# Read in Panda file
	def getPdFile(self,fileName=None,type=None,folder=None,values=None,addFileExt=True,indexCol=False,replaceNull=False,delimiter=',',encoding='ISO-8859-1',path=None,jsonRecordPath=None,meta=None):
		df = pd.DataFrame()
		if type == 'csv':
			if addFileExt:
				if path is None:
					path = self.fileDirectory
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(path,folder,fileName),'csv'),encoding=encoding,index_col=indexCol,sep=delimiter)
				if replaceNull:
					df = mixedDf
				else:
					df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
			else:
				if path is None:
					path = self.fileDirectory
				mixedDf = pd.read_csv(os.path.join(path,folder,fileName),encoding=encoding,sep=delimiter)
				if replaceNull:
					df = mixedDf
				else:
					df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
		elif type == 'json':
			if values is not None:
				#df= pd.DataFrame.from_records(values)
				if jsonRecordPath is not None:
					df=pd.json_normalize(values,record_path=jsonRecordPath,meta=meta)
				else:
					if replaceNull:
						df=self.flattenJsonData(values)
						df.fillna("",inplace=True)
					else:
						df=self.flattenJsonData(values)
			else:
				df= pd.read_json(fileName)
		elif type== 'sql':
			if path is None:
				path = self.fileDirectory
			engine = self.getDBConnection('MSACCESS','')
			df = pd.read_sql('tRM_CSB_Maternite',engine)
			df.to_csv(os.path.join(path,folder,'mdg.csv'), sep=',', encoding='utf-8')
		else:
			pass
		df.dropna(axis=0,how="all")
		df.dropna(axis=1,how="all")
		return df

    # create Panda Data Frame from event data
	def createDataFrame(self,events,type):
		cols = self.createColumns(events['headers'],type)
		dataFrame = pd.DataFrame.from_records(events['rows'],columns=cols)
		return dataFrame
	# Get Uids from mappings
	def getUid(self,column,id):
		return id
	# Join strings
	def strJoin(self,*args):
		return ''.join(map(str, args))
	#create DHIS2 periods
	def createPeriods(self,**args):
		p = pd.to_datetime("{}-{}".format(args["year"],args["month"]))
		period = self.strJoin(f"{p:%Y}",f"{p:%m}")
		return period

	# create Output files
	def createResultFile(self,values,folder,filename,type=None,chunksize=None,addFileExt=True,sheetName="Sheet1",path=None,index=False):
		if values is not None:
			values.drop(values.columns[values.columns.str.contains('unnamed',case=False)],axis=1,inplace=True)
		if path is None:
			path = self.fileDirectory
		if type=='csv':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				values.to_csv(os.path.join(path,folder,filename), sep=',', encoding='utf-8',chunksize=chunksize,index=index)
			else:
				values.to_csv(os.path.join(path,folder,filename), sep=',', encoding='utf-8',chunksize=chunksize,index=index)
		elif type=='xlsx':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				with pd.ExcelWriter(os.path.join(path,folder,filename)) as writer:
					values.to_excel(writer,sheet_name=sheetName)
			else:
				with pd.ExcelWriter(os.path.join(path,folder,filename)) as writer:
					values.to_excel(writer,sheet_name=sheetName)
		elif type=='tsv':
			if addFileExt:
				filename = "{}.{}".format(filename,type)
				values.to_csv(os.path.join(path,folder,filename), sep='\t', encoding='utf-8',chunksize=chunksize,index=index)
			else:
				values.to_csv(os.path.join(path,folder,filename), sep='\t', encoding='utf-8',chunksize=chunksize,index=index)

		else:
			filename = "{}.{}".format(filename,type)
			values.to_json(os.path.join(path,folder,filename),orient='records')
		return 'SUCCESS'

	# Split csv files
	def splitFile(self,fileName=None,type='csv',folder=None,values=None,chunksize=100000,chunkType='size',columns=None,dropColumns=None):
		dfFiles = []
		if type == 'csv':
			if chunkType == 'files':
				# Read files name
				fileLocation= os.listdir(os.path.join(self.fileDirectory,folder))
				for entry in fileLocation:
					if fileName in entry:
						dfFiles.append(entry)
			elif chunkType == 'column' and columns is not None:
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(self.fileDirectory,folder,fileName),'csv'),encoding='ISO-8859-1')
				uniqueColumnData = mixedDf[columns].unique().tolist()
				#df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
				for columnValue in uniqueColumnData:
					print("File chunk by column value: ",columnValue)
					filename = '{}_{}'.format(fileName,columnValue)
					dfFiles.append(filename)
					filename = '{}.{}'.format(filename,type)
					queryColumn = "{}{}{}{}{}".format(columns,'==','"',columnValue,'"')
					chunkQuery = mixedDf.query(queryColumn)
					if dropColumns is not None:
						chunk = chunkQuery.drop(columns=dropColumns)
						chunk.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',', encoding='ISO-8859-1',index=False)
					else:
						chunkQuery.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',',encoding='ISO-8859-1',index=False)
			else:
				mixedDf = pd.read_csv('{}.{}'.format(os.path.join(self.fileDirectory,folder,fileName),'csv'),encoding='ISO-8859-1',iterator=True, chunksize=chunksize)
				#df = mixedDf[mixedDf.columns].applymap(lambda x: str(x) if x == x else "")
				for i, chunk in enumerate(mixedDf):
					print("File chunk ",i)
					filename = '{}_{}_{}.{}'.format(fileName,'chunk',i,type)
					dfFiles.append(filename)
					chunk.to_csv(os.path.join(self.fileDirectory,folder,filename), sep=',', encoding='utf-8',index=False)
		else:
			pass
		return dfFiles

	# Check duplicates
	# keep { first, last, False }
	def markDuplicate(self,source=None,columns=None,label="Duplicated",keep=False):
		if source is not None and columns is not None:
			source[label] = source.duplicated(subset=columns,keep=keep)
			return source
		else:
			print("Specify source and columns")
			return source
	# Analyse duplicates based on input csv file or same system
	def analyzeDuplicates(self,source=None,validate=None,type=None,leftColumns=None,rightColumns=None,duplicated=None,dupColumns=None,expression=None):
		merged = None
		if type.lower() ==  "csv":
			if duplicated == 'keep':
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
			elif duplicated == 'remove':
				merged_with_duplicates = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
				merged = merged_with_duplicates.drop_duplicates(subset=dupColumns)
			else:
				merged = pd.merge(validate,source,how='left',left_on=leftColumns,right_on=rightColumns)
		elif type.lower() == 'system':
			merged = validate.query(expression)
			merged['duplicated'] = merged.duplicated(subset=dupColumns,keep=False)
		return merged

	# Join dataValues
	def combineData(self,df,data=None,leftColumns=None,rightColumns=None,how='left',suffixes=('_x','_y')):
		return pd.merge(df,data,how=how,left_on=leftColumns,right_on=rightColumns,suffixes=suffixes)

	# Combine two unequal data frames
	def combineNonEqualData(self,left,right,leftColumns=None,rightColumns=None,how='left',suffixes=('_x','_y')):
		leftRows = len(left.index)
		rightRows = len(right.index)
		rows = divmod(leftRows,rightRows)

		resultDf = pd.DataFrame()
		for x in range(rows[0]):
			mergedDf = self.combineData(df=left[(rightRows*x):rightRows*(x+1)],data=right,leftColumns=leftColumns,rightColumns=rightColumns,how=how,suffixes=suffixes)
			resultDf = pd.concat([resultDf,mergedDf])
			if x == (rows[0]-1):
				if rows[1] > 0:
					mergedRemainderDf = self.combineData(df=left[rightRows*(x+1):(rightRows*(x+1))+rows[1]],data=right,leftColumns=leftColumns,rightColumns=rightColumns,how=how,suffixes=suffixes)
					pd.concat([resultDf,mergedRemainderDf])
		return resultDf



	# Check if string is in text
	def isStringInText(self,phrase, text):
		return re.search(r"\b{}\b".format(phrase), text, re.IGNORECASE) is not None
	# Check if string is in text
	def isFullStringInText(self,phrase, text):
		return re.match(r"\w+\Z".format(phrase), text, re.IGNORECASE) is not None
	# Rename columns in a dataframe
	def renameColumns(self,data=None,columns=None):
		dataValues = data.rename(columns=columns)
		return dataValues
	# Get database connections
	def getDBConnection(self,driver=None,path="c:\\",db='data',dbExt="mdb",dsn=None,mode="ro",encoding='utf-8'):
		
		engine = None
		installedDriver = [x for x in pyodbc.drivers() if x.startswith('Microsoft Access Driver')]
		connectionString = 'DRIVER={};DBQ={}{}.{};ExtendedAnsiSQL=1;'.format("{Microsoft Access Driver (*.mdb, *.accdb)}",path,db,dbExt)
		print("Installed Drivers::",installedDriver)
		if driver == 'msaccess':
			params = urllib.parse.quote_plus(connectionString)
			connectionUri = f"access+pyodbc:///?odbc_connect={params}"
			engine = sql.create_engine(connectionUri)
		elif driver == 'dsn':
			connectionUri = f"access+pyodbc://{dsn}"
			engine = sql.create_engine(connectionUri)
		elif driver == 'sqlite':
			connectionUri = 'sqlite:///{}{}'.format(path,db)
			#params = urllib.parse.quote_plus(connectionUri)
			engine = sql.create_engine(connectionUri,encoding=encoding)
			engine.text_factory = lambda b: b.decode(errors = 'ignore')
		elif driver == 'mysql' or driver == 'mariadb':
			connectionUri = "mysql+pymysql://{}:{}@{}/{}?charset=utf8mb4".format(username,password,host,db)
			params = urllib.parse.quote_plus(connectionUri)
			engine = sql.create_engine(params)
		elif driver == 'postgresql':
			connectionUri = "postgresql+pg8000://{}:{}@{}/{}".format(username,password,host,db)
			params = urllib.parse.quote_plus(connectionUri)
			engine = sql.create_engine(params,client_encoding='utf8')
		elif driver == 'mssql':
			params = urllib.parse.quote_plus("DRIVER={SQL Server Native Client 10.0};SERVER=dagger;DATABASE=" +db+";UID=user;PWD=password")
			engine = sql.create_engine("mssql+pyodbc:///?odbc_connect=%s" % params)
		else:
			pass
		print("engine:",engine)
		##Base = declarative_base(engine)
		Base = automap_base()
		# produce our own MetaData object
		metadata = MetaData()

		# we can reflect it ourselves from a database, using options
		# such as 'only' to limit what tables we look at...
		metadata.reflect(engine)
		#Base = automap_base(metadata=metadata)
		# reflect the tables
		#Base.prepare()
		Base.prepare(engine, reflect=True)
		#print("Base::",Base.classes)
		##metadata = Base.metadata
		Session = sessionmaker(bind=engine)
		# associate it with our custom Session class
		#Session.configure(bind=engine)

		# work with the session
		session = Session()
		return (engine,session,metadata,Base)
