# -*- coding: utf-8 -*-
#!/usr/bin/env python
# Map gesis to DHIS2
#


from __future__ import absolute_import, division, print_function, unicode_literals
# stdlib
import requests,urllib
import os
import string
import random
import json

# Zato
#from zato.server.service import Service

class hisApi:
	def __init__(self):
		self.path = os.path.abspath(os.path.dirname(__file__))
		newPath = self.path.split('/')
		newPath.pop(-1)
		self.fileDirectory = '/'.join(newPath)
		self.url = ""
		self.username = ''
	# Get HTTP session
	def getLoginSession(self,username,password,sid=None,verify=False):
		session = requests.Session()
		session.auth = (username,password)
		session.headers.update({'X-IEngine': sid})
		session.verify = verify
		return session
	# Get Authentication details e.g .his_config.json
	def getAuth(self,secrets=None,path=None):
		if path is None:
			path = self.fileDirectory
		if secrets is None:
			secrets = '.his_config.json'
		with open(os.path.join(path,secrets),'r') as jsonfile:
			auth = json.load(jsonfile)
			#auth = bunch.Bunch(auth)
			print("Authentication credentials loaded successfully")
			return auth
	def getDHIS2ItemById(self,url,session,item,id):
	    items = []
	    try:
	        get_request = session.get(url + "/api/" + item + "/" + id + ".json",params={"paging":"false"})
	        print(str(get_request.status_code))
	        items = get_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Get DHIS2 Item
	def getDHIS2Item(self,url,session,item,params=None):
	    items = []
	    if params is None:
	    	params = {}

	    try:
	        get_request = session.get(url + "/api/" + item + ".json",params=params)
	        print("HTTP request ({}) returned: {} ".format(item,str(get_request.status_code)))
	        items = get_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Post DHIS2 item
	def postDHIS2Item(self,url,session,item,data=None):
	    items = []
	    try:
	        post_request = session.post(url + "/api/" + item,json=data)
	        print("HTTP request ({}) returned: {} ".format(item,str(post_request.text)))
	        items = post_request.json()
	        return items
	    except urllib.request.URLError as e:
	        print(e)
	    return items
	# Update DHIS2 item
	def updateDHIS2Item(self,url,session,item,data):
	    items = []
	    try:
	        put_request = session.put(url + "/api/" + item,json=data)
	        print("HTTP request ({}) returned: {} ".format(item,str(put_request.text)))
	        items = put_request.json()
	        return items
	    except requests.exceptions.RequestException as e:
	        print(e)
	    return items
